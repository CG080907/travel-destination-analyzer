# config.py
from __future__ import annotations
import os
import ssl
import os.path

# Basisverzeichnisse
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")

# --- MapToolkit / Tiles ---
MAPTOOLKIT_RAPIDAPI_KEY  = os.getenv("MAPTOOLKIT_RAPIDAPI_KEY", "")
MAPTOOLKIT_RAPIDAPI_HOST = os.getenv("MAPTOOLKIT_RAPIDAPI_HOST", "maptiles.p.rapidapi.com")
MAPTOOLKIT_RAPIDAPI_PATH_TEMPLATE = os.getenv(
    "MAPTOOLKIT_RAPIDAPI_PATH_TEMPLATE",
    "/en/map/v1/{z}/{x}/{y}.png"
)

# --- Booking / RapidAPI ---
BOOKING_RAPIDAPI_KEY  = os.getenv("BOOKING_RAPIDAPI_KEY", "")
BOOKING_RAPIDAPI_HOST = os.getenv("BOOKING_RAPIDAPI_HOST", "")

# --- Google AI Studio (Gemini) ---
GOOGLE_AI_STUDIO_API_KEY = os.getenv("GOOGLE_AI_STUDIO_API_KEY", "")
GOOGLE_AI_STUDIO_MODEL    = os.getenv("GOOGLE_AI_STUDIO_MODEL", "gemini-2.5-flash")

# --- CSV-Pfade ---
CLIMATE_CSV_PATH = os.path.join(DATA_DIR, "climate_weekly.csv")
FX_CSV_PATH      = os.path.join(DATA_DIR, "KursExport.csv")

# --- SSL-Kontext ---
SSL_CTX = ssl.create_default_context()
