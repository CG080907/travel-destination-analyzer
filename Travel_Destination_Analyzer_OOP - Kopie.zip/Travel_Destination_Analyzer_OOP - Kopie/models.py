# models.py
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, Optional

@dataclass
class TravelRequest:
    checkin: str
    checkout: str
    adults: int
    budget: float
    tmin: float
    tmax: float
    triptype: str
    origin: str
    mode: str
    actppd: float

@dataclass
class TravelRow:
    destination: str
    score: float
    season_temp: float
    condition: str
    condition_en: str
    cost_ppd: float
    lat: float
    lon: float
    budget_total: float
    country: str
    travel: Dict[str, Any]
    costs: Dict[str, Any]
    links: Dict[str, str]
    suggested: Optional[Dict[str, Any]] = None

