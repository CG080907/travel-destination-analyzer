# main.py
from __future__ import annotations
from http.server import HTTPServer
from config import MAPTOOLKIT_RAPIDAPI_KEY, GOOGLE_AI_STUDIO_API_KEY
from services.climate_service import ClimateService
from services.fx_service import FXService
from services.travel_service import TravelService
from services.booking_service import BookingService
from services.hazards_service import HazardsService
from services.geocode_service import GeocodeService
from services.maptiles_service import MapTilesService
from web.handler import make_handler

def main():
    host, port = "127.0.0.1", 8000
    print("🌍 Travel Destination Analyzer")
    print(f" → http://{host}:{port}")

    if not MAPTOOLKIT_RAPIDAPI_KEY:
        print("ℹ️ Ohne MAPTOOLKIT_RAPIDAPI_KEY werden OSM-Standardtiles genutzt (kein MapToolKit).")
    if not GOOGLE_AI_STUDIO_API_KEY:
        print("ℹ️ Kein GOOGLE_AI_STUDIO_API_KEY gesetzt – /api/ask liefert Fehlermeldung.")

    climate  = ClimateService()
    fx       = FXService()
    booking  = BookingService()
    geocode  = GeocodeService()
    tiles    = MapTilesService()
    hazards  = HazardsService()
    travel   = TravelService(climate=climate, booking=booking, geocode=geocode)

    handler_cls = make_handler(
        climate=climate,
        fx=fx,
        travel=travel,
        booking=booking,
        hazards=hazards,
        geocode=geocode,
        tiles=tiles,
    )

    print("Beenden mit STRG+C")
    HTTPServer((host, port), handler_cls).serve_forever()

if __name__ == "__main__":
    main()

