# web/handler.py
from __future__ import annotations
from http.server import BaseHTTPRequestHandler
from urllib.parse import urlparse
import json
from config import MAPTOOLKIT_RAPIDAPI_KEY
from .html_template import INDEX_HTML_TEMPLATE
from services.fx_service import FXService
from services.travel_service import TravelService, guides_offline, travel_estimate, nearest_point
from services.climate_service import ClimateService
from services.booking_service import BookingService
from services.hazards_service import HazardsService
from services.geocode_service import GeocodeService
from services.maptiles_service import MapTilesService
from services.destinations_data import AIRPORTS, TRAIN_HUBS
from models import TravelRequest

def make_handler(
    climate: ClimateService,
    fx: FXService,
    travel: TravelService,
    booking: BookingService,
    hazards: HazardsService,
    geocode: GeocodeService,
    tiles: MapTilesService,
):
    class Handler(BaseHTTPRequestHandler):
        def _send(self, code: int, body: bytes, ctype: str = "text/html; charset=utf-8"):
            try:
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                if body:
                    try:
                        self.wfile.write(body)
                    except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError):
                        pass
            except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError):
                pass

        def do_GET(self):
            p = urlparse(self.path).path
            if p == "/":
                has_tiles = "true" if MAPTOOLKIT_RAPIDAPI_KEY else "false"
                html = (
                    INDEX_HTML_TEMPLATE
                    .replace("{{HAS_MAPTOOLKIT}}", has_tiles)
                    .replace("{{CURRENCIES_JSON}}", json.dumps(fx.currencies))
                )
                return self._send(200, html.encode("utf-8"))

            if p.startswith("/tiles/") and p.endswith(".png"):
                try:
                    _, _, z, x, y_png = p.split("/", 4)
                    y = y_png[:-4]
                    z_i, x_i, y_i = int(z), int(x), int(y)
                    data = tiles.fetch_tile_png(z_i, x_i, y_i)
                    if not data:
                        return self._send(502, b"", "image/png")
                    return self._send(200, data, "image/png")
                except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError):
                    return
                except Exception:
                    return self._send(500, b"", "image/png")

            return self._send(404, b"Not Found", "text/plain; charset=utf-8")

        def do_POST(self):
            p = urlparse(self.path).path
            length = int(self.headers.get("Content-Length", "0"))
            try:
                payload = json.loads(self.rfile.read(length) or b"{}")
            except Exception:
                payload = {}

            if p == "/api/analyze":
                req = TravelRequest(
                    checkin  = str(payload.get("checkin","") or ""),
                    checkout = str(payload.get("checkout","") or ""),
                    adults   = int(payload.get("adults",2)),
                    budget   = float(payload.get("budget",150.0)),
                    tmin     = float(payload.get("tmin",18.0)),
                    tmax     = float(payload.get("tmax",28.0)),
                    triptype = str(payload.get("triptype","city")),
                    origin   = str(payload.get("origin","") or ""),
                    mode     = str(payload.get("mode","car")),
                    actppd   = float(payload.get("actppd",30.0)),
                )
                rows = travel.analyze(req)
                return self._send(200, json.dumps({"rows": rows}, ensure_ascii=False).encode("utf-8"),
                                  "application/json; charset=utf-8")

            if p == "/api/hotels":
                city    = str(payload.get("city",""))
                checkin = str(payload.get("checkin","") or "")
                checkout= str(payload.get("checkout","") or "")
                adults  = int(payload.get("adults",2))
                avg, hotels = booking.booking_avg_price_and_hotels(city, checkin, checkout, adults)
                return self._send(200, json.dumps({"avg": avg, "hotels": hotels}, ensure_ascii=False).encode("utf-8"),
                                  "application/json; charset=utf-8")

            if p == "/api/hazards":
                country = str(payload.get("country","")).upper()
                items = hazards.get_hazards(country)
                link = hazards.get_aa_link(country)
                return self._send(200, json.dumps({"items": items, "link": link}, ensure_ascii=False).encode("utf-8"),
                                  "application/json; charset=utf-8")

            if p == "/api/convert":
                amount = float(payload.get("amount",0.0))
                frm    = (payload.get("frm","EUR") or "EUR").upper()
                to     = (payload.get("to","USD") or "USD").upper()
                res = fx.convert(amount, frm, to)
                if res is None:
                    return self._send(200, json.dumps({"error":"Umrechnung fehlgeschlagen."}, ensure_ascii=False).encode("utf-8"),
                                      "application/json; charset=utf-8")
                return self._send(200, json.dumps({"result": float(res)}, ensure_ascii=False).encode("utf-8"),
                                  "application/json; charset=utf-8")

            if p == "/api/route":
                origin = str(payload.get("origin","") or "")
                dest   = payload.get("dest") or {}
                mode   = str(payload.get("mode","car"))
                dlat, dlon = float(dest.get("lat",0)), float(dest.get("lon",0))
                olat, olon, oname = geocode.resolve_origin(origin)
                trv = travel_estimate(olat, olon, dlat, dlon, mode)
                coords = None
                suggested = None
                if None not in (olat,olon,dlat,dlon):
                    coords = [[olon, olat],[dlon, dlat]]
                if mode == "flight" and olat is not None:
                    dep, _ = nearest_point(olat, olon, AIRPORTS)
                    if dep: suggested = {"type":"airport","code":dep["code"],"name":dep["name"]}
                elif mode == "train" and olat is not None:
                    dep, _ = nearest_point(olat, olon, TRAIN_HUBS)
                    if dep: suggested = {"type":"train","name":dep["name"]}
                return self._send(200, json.dumps({
                    "origin":{"lat":olat,"lon":olon,"name":oname or origin},
                    "distance_km":trv["distance_km"], "time_h":trv["time_h"], "cost_eur":trv["cost_eur"],
                    "coords": coords, "suggested": suggested
                }, ensure_ascii=False).encode("utf-8"),
                                  "application/json; charset=utf-8")

            if p == "/api/ask":
                from services.ai_service import AIService
                q = str(payload.get("q","")).strip()
                if not q:
                    return self._send(200, json.dumps({"error":"empty"}, ensure_ascii=False).encode("utf-8"),
                                      "application/json; charset=utf-8")
                ai = AIService()
                text, err = ai.ask(q)
                if text:
                    return self._send(200, json.dumps({"text": text}, ensure_ascii=False).encode("utf-8"),
                                      "application/json; charset=utf-8")
                return self._send(200, json.dumps({"error":"AI request failed", "detail": err}, ensure_ascii=False).encode("utf-8"),
                                  "application/json; charset=utf-8")

            return self._send(404, b"Not Found", "text/plain; charset=utf-8")

        def log_message(self, format, *args):
            try:
                p = urlparse(getattr(self, "path", "")).path
                if p.startswith("/tiles/"):
                    return
            except Exception:
                pass
            super().log_message(format, *args)

    return Handler
