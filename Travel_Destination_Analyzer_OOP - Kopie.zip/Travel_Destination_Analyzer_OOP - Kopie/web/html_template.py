INDEX_HTML_TEMPLATE = """<!doctype html>
<html lang="de"><head>
<meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>Travel Destination Analyzer</title>
<link href="https://unpkg.com/maplibre-gl@3.6.1/dist/maplibre-gl.css" rel="stylesheet" />
<script src="https://unpkg.com/maplibre-gl@3.6.1/dist/maplibre-gl.js"></script>
<style>
:root{--bg:#0b1324;--card:#121a2b;--muted:#a7b0c3;--text:#f1f5ff;--accent:#4fc3f7;}
*{box-sizing:border-box}
body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Arial;background:var(--bg);color:var(--text)}
.container{max-width:1240px;margin:0 auto;padding:20px}
.header{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}
.brand{display:flex;align-items:center;gap:10px}
.brand h1{margin:0;font-weight:800}
.lang{display:flex;align-items:center;gap:8px}
.lang select{background:#0f1730;border:1px solid #263152;color:#fff;padding:8px 10px;border-radius:8px;height:40px}
.card{background:var(--card);border:1px solid #1d2742;border-radius:14px;padding:14px}
.grid{display:grid;gap:14px}
.filters{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(160px,1fr));
  gap:12px;
  align-items:stretch;
}
.input{display:flex;flex-direction:column;justify-content:space-between;gap:6px;min-height:90px}
.input label{font-size:12px;color:var(--muted)}
.input input, .input select, .input textarea{
  background:#0f1730;border:1px solid #263152;color:#fff;
  padding:8px 10px;border-radius:8px;height:36px;line-height:20px;
}
.input textarea{height:80px}
.input .btn{align-self:flex-start;margin-top:auto;height:36px}
.btn{appearance:none;border:0;background:linear-gradient(135deg,#4fc3f7,#7c4dff);color:#fff;padding:8px 12px;border-radius:9px;cursor:pointer;font-weight:700}
.btn2{appearance:none;border:0;background:#22345f;color:#cfe3ff;padding:8px 12px;border-radius:8px;cursor:pointer}
.btn:active{transform:translateY(1px)}
.badge{display:inline-block;padding:2px 8px;border-radius:999px;background:#1f2a49;color:#c9d5ff;font-size:12px}
.board{
  display:grid;
  grid-template-columns:minmax(0,2.4fr) minmax(0,1.1fr) minmax(0,1.1fr);
  gap:14px;
  margin-top:14px;
}
#mapCard{grid-row:1/3;grid-column:1/2}
.kpiCol{grid-row:1/3;grid-column:2/3;display:grid;gap:14px}
.kpiItem{min-height:120px}
#routeCard{grid-row:1/3;grid-column:3/4;min-height:250px}
.map{height:420px;border-radius:12px;border:1px solid #263152;overflow:hidden;background:#0f1730}
.maplibregl-popup-content{background:#ffffff;color:#0b1324;border-radius:8px;box-shadow:0 10px 30px rgba(0,0,0,.5)}
.maplibregl-popup-tip{border-top-color:#ffffff !important}
.maplibregl-ctrl,.maplibregl-ctrl-group{background:#ffffff !important;color:#0b1324}
.maplibregl-ctrl button{filter:none}
.bottomRow{
  display:grid;
  grid-template-columns:2fr 1.4fr 1.6fr;
  gap:14px;
  margin-top:14px;
}
.flex{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.table{width:100%;border-collapse:collapse;font-size:14px;margin-top:14px}
.table th,.table td{padding:10px 12px;border-bottom:1px solid #223058}
.table th{color:#b7c1d9;text-align:left;font-weight:600}
.details{
  position:fixed;right:16px;top:16px;bottom:16px;width:420px;
  background:#0f1730;border:1px solid #263152;border-radius:12px;
  padding:12px;box-shadow:0 14px 28px rgba(0,0,0,.4);
  display:none;overflow:auto;z-index:50
}
.details h3{margin:4px 0 8px;font-size:18px}
.sight{margin-bottom:8px}
.hotel{display:flex;justify-content:space-between;border-bottom:1px dashed #263152;padding:6px 0}
.costgrid{display:grid;grid-template-columns:1fr auto;gap:6px;align-items:center}
.linkrow{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}
@media (max-width:980px){
  .board{grid-template-columns:1fr;grid-auto-rows:auto}
  #mapCard,.kpiCol,#routeCard{grid-row:auto;grid-column:1/2}
  .bottomRow{grid-template-columns:1fr}
  .details{position:fixed;width:100%;left:0;right:0;top:0;bottom:0;border-radius:0}
}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <div class="brand">
      <div style="font-size:22px">🌍</div>
      <h1 id="t_title">Travel Destination Analyzer</h1>
    </div>
    <div class="lang">
      <label for="langSel" style="color:#b7c1d9" id="t_lang">Sprache</label>
      <select id="langSel">
        <option value="de" selected>Deutsch</option>
        <option value="en">English</option>
      </select>
    </div>
  </div>

  <div class="card filters">
    <div class="input"><label id="t_checkin">Check-in (optional)</label><input id="checkin" type="date"/></div>
    <div class="input"><label id="t_checkout">Check-out (optional)</label><input id="checkout" type="date"/></div>
    <div class="input"><label id="t_persons">Personen</label><input id="adults" type="number" min="1" value="2"/></div>
    <div class="input"><label id="t_tmin">Temp min (°C)</label><input id="tmin" type="number" value="18"/></div>
    <div class="input"><label id="t_tmax">Temp max (°C)</label><input id="tmax" type="number" value="28"/></div>
    <div class="input"><label id="t_origin">Startort (für Route)</label><input id="origin" placeholder="Beliebige Stadt, z.B. München, Paris"/></div>
    <div class="input"><label id="t_mode">Modus</label>
      <select id="mode"><option value="car" selected>Auto</option><option value="train">Zug</option><option value="flight">Flug</option></select>
    </div>
    <div class="input"><label id="t_budget_ppd">Budget/Tag p.P. (€)</label><input id="budget" type="number" value="150" min="40" step="10"/></div>
    <div class="input"><label id="t_actppd">Aktivitäten €/Tag p.P.</label><input id="actppd" type="number" value="30" min="0" step="5"/></div>
    <div class="input"><label id="t_triptype">Art der Reise</label>
      <select id="triptype">
        <option value="city" selected>Citytrip</option>
        <option value="strand">Strandurlaub</option>
        <option value="familie">Familienurlaub</option>
        <option value="outdoor">Wandern & Outdoor</option>
        <option value="ski">Skifahren</option>
        <option value="natur">Naturreisen</option>
        <option value="wellness">Entspannung & Wellness</option>
        <option value="kultur">Sightseeing & Kultur</option>
        <option value="party">Partyurlaub</option>
      </select>
    </div>
    <div class="input"><label id="t_markers">Nur Top-3</label>
      <select id="onlytop"><option value="1" selected>Ja</option><option value="0">Alle</option></select>
    </div>
    <div class="input"><label>&nbsp;</label><button class="btn" id="runBtn">Analysieren</button></div>
  </div>

  <div class="board">
    <div class="card" id="mapCard">
      <div class="badge" id="t_map">Karte</div>
      <div id="map" class="map"></div>
    </div>

    <div class="kpiCol">
      <div class="card kpiItem">
        <div class="badge" id="t_top">Top-Ziel</div>
        <div id="bestTitle" style="font-size:18px;margin-top:6px">–</div>
        <div id="bestMeta" style="color:#b7c1d9;margin-top:4px">–</div>
      </div>
      <div class="card kpiItem">
        <div class="badge" id="t_filter">Ausgewählte Filter</div>
        <div id="kpiFilters" style="margin-top:6px;color:#cfe3ff;font-size:13px">–</div>
      </div>
      <div class="card kpiItem">
        <div class="badge" id="t_count">Anzahl der Ziele</div>
        <div id="kpiCount" style="font-size:26px;margin-top:10px">–</div>
      </div>
    </div>

    <div class="card" id="routeCard">
      <div class="badge" id="t_route_box">Anreise / Route</div>
      <div id="routeSummary" style="margin-top:8px;color:#cfe3ff;font-size:14px">Noch keine Route berechnet.</div>
    </div>
  </div>

  <div class="bottomRow">
    <div class="card">
      <div class="badge" id="t_fx">Währungsumrechner</div>
      <div class="flex" style="margin-top:8px">
        <input id="fx_amount" style="width:120px" value="100" />
        <select id="fx_from" style="width:110px"></select>
        <span>→</span>
        <select id="fx_to" style="width:110px"></select>
        <button class="btn2" id="fxBtn">Umrechnen</button>
      </div>
      <div id="fx_out" style="margin-top:8px;color:#cfe3ff">–</div>
    </div>

    <div class="card">
      <div class="badge" id="t_ai_title">Spezialanfrage (Gemini)</div>
      <div class="input" style="min-height:unset;margin-top:8px">
        <textarea id="aiq" rows="2" placeholder="z.B. »Gib mir 3 Insider-Tipps für Mallorca im Mai.«" style="height:80px"></textarea>
      </div>
      <button class="btn2" id="aiBtn">Fragen</button>
      <div id="aiOut" style="margin-top:8px;color:#cfe3ff">–</div>
    </div>

    <div class="card">
      <div class="badge" id="t_gyg_title">Aktivitäten & Inspiration</div>
      <div id="gygCity" style="color:#b7c1d9;margin-top:4px">–</div>
      <div id="gyg" style="margin-top:8px;color:#cfe3ff">Bitte Analyse ausführen…</div>
    </div>
  </div>

  <div class="card" style="margin-top:14px; overflow:auto">
    <table class="table" id="tbl">
      <thead><tr>
        <th>#</th><th id="t_dest">Destination</th><th>Score</th><th id="t_season">Temp (Saison)</th><th id="t_weather">Wetter</th><th id="t_costppd">€/Tag p.P.</th><th id="t_total">Budget gesamt</th><th id="t_dist">Entfernung</th><th id="t_details">Details</th><th id="t_route_btn">Route</th>
      </tr></thead>
      <tbody></tbody>
    </table>
  </div>
</div>

<div id="details" class="details">
  <div style="display:flex;justify-content:space-between;align-items:center">
    <h3 id="detTitle">Details</h3>
    <button class="btn2" onclick="toggleDetails(false)" id="t_close">Schließen</button>
  </div>
  <div id="detMeta" style="color:#b7c1d9;margin-bottom:8px">–</div>

  <div class="badge" style="margin-bottom:8px" id="t_cost_breakdown">Kostenaufschlüsselung</div>
  <div id="detCosts" class="costgrid"></div>
  <div id="detCostExplain" style="margin-top:8px;font-size:13px;color:#cfe3ff"></div>
  <div class="linkrow" id="detCostLinks"></div>

  <div class="badge" style="margin:12px 0 8px" id="t_sights">Top-Sehenswürdigkeiten</div>
  <div id="detSights"></div>
  <div class="badge" style="margin:12px 0 8px" id="t_hotels">Hotels & Apartments (Preis/Nacht, Score)</div>
  <div id="detHotels"></div>
  <div class="badge" style="margin:12px 0 8px" id="t_hazards">Warnhinweise & Saison</div>
  <div id="detHazards"></div>
</div>

<script>
const HAS_MAPTOOLKIT = {{HAS_MAPTOOLKIT}};
const CURRENCIES = {{CURRENCIES_JSON}};

const I18N = {
  de: {
    title:"Travel Destination Analyzer", lang:"Sprache",
    checkin:"Check-in (optional)", checkout:"Check-out (optional)", persons:"Personen",
    budget_ppd:"Budget/Tag p.P. (€)", tmin:"Temp min (°C)", tmax:"Temp max (°C)",
    triptype:"Art der Reise", origin:"Startort (für Route)", mode:"Modus",
    actppd:"Aktivitäten €/Tag p.P.", markers:"Nur Top-3", map:"Karte",
    gyg_title:"Aktivitäten & Inspiration", fx:"Währungsumrechner",
    ai_title:"Spezialanfrage (Gemini)", top:"Top-Ziel", filter:"Ausgewählte Filter",
    count:"Anzahl der Ziele", dest:"Destination", season:"Temp (Saison)", weather:"Wetter",
    costppd:"€/Tag p.P.", total:"Budget gesamt", dist:"Entfernung", details:"Details", route:"Route",
    close:"Schließen", cost_breakdown:"Kostenaufschlüsselung", sights:"Top-Sehenswürdigkeiten",
    hotels:"Hotels & Apartments (Preis/Nacht, Score)", hazards:"Warnhinweise & Saison",
    fotos:"📷 Fotos zum Ort", analyze:"Analysieren",
    drive:"Strecke", flight:"Luftlinie",
    gyg_loading:"Bitte Analyse ausführen…",
    fx_failed:"Umrechnung fehlgeschlagen",
    ai_enter:"Bitte eine Frage eingeben.",
    route_box:"Anreise / Route",
    aa_link:"Auswärtiges Amt: Reise- und Sicherheitshinweise"
  },
  en: {
    title:"Travel Destination Analyzer", lang:"Language",
    checkin:"Check-in (optional)", checkout:"Check-out (optional)", persons:"People",
    budget_ppd:"Budget/day pp (€)", tmin:"Temp min (°C)", tmax:"Temp max (°C)",
    triptype:"Trip type", origin:"Origin (for route)", mode:"Mode",
    actppd:"Activities €/day pp", markers:"Top-3 only", map:"Map",
    gyg_title:"Activities & inspiration", fx:"Currency converter",
    ai_title:"Special query (Gemini)", top:"Top destination", filter:"Selected filters",
    count:"Number of destinations", dest:"Destination", season:"Season temp", weather:"Weather",
    costppd:"€/day pp", total:"Total budget", dist:"Distance", details:"Details", route:"Route",
    close:"Close", cost_breakdown:"Cost breakdown", sights:"Top sights",
    hotels:"Hotels & apartments (price/night, score)", hazards:"Advisories & season",
    fotos:"📷 Photos", analyze:"Analyze",
    drive:"Distance", flight:"Great-circle",
    gyg_loading:"Run analysis…",
    fx_failed:"Conversion failed",
    ai_enter:"Please enter a question.",
    route_box:"Travel / Route",
    aa_link:"German foreign office travel advice"
  }
};
let LANG = 'de';
function t(k){ return (I18N[LANG] && I18N[LANG][k])||k; }
function applyLang(){
  document.getElementById('t_title').textContent=t('title');
  document.getElementById('t_lang').textContent=t('lang');
  document.getElementById('t_checkin').textContent=t('checkin');
  document.getElementById('t_checkout').textContent=t('checkout');
  document.getElementById('t_persons').textContent=t('persons');
  document.getElementById('t_budget_ppd').textContent=t('budget_ppd');
  document.getElementById('t_tmin').textContent=t('tmin');
  document.getElementById('t_tmax').textContent=t('tmax');
  document.getElementById('t_triptype').textContent=t('triptype');
  document.getElementById('t_origin').textContent=t('origin');
  document.getElementById('t_mode').textContent=t('mode');
  document.getElementById('t_actppd').textContent=t('actppd');
  document.getElementById('t_markers').textContent=t('markers');
  document.getElementById('runBtn').textContent=t('analyze');
  document.getElementById('t_map').textContent=t('map');
  document.getElementById('t_gyg_title').textContent=t('gyg_title');
  document.getElementById('t_fx').textContent=t('fx');
  document.getElementById('t_ai_title').textContent=t('ai_title');
  document.getElementById('t_top').textContent=t('top');
  document.getElementById('t_filter').textContent=t('filter');
  document.getElementById('t_count').textContent=t('count');
  document.getElementById('t_dest').textContent=t('dest');
  document.getElementById('t_season').textContent=t('season');
  document.getElementById('t_weather').textContent=t('weather');
  document.getElementById('t_costppd').textContent=t('costppd');
  document.getElementById('t_total').textContent=t('total');
  document.getElementById('t_dist').textContent=t('dist');
  document.getElementById('t_details').textContent=t('details');
  document.getElementById('t_route_btn').textContent=t('route');
  document.getElementById('t_close').textContent=t('close');
  document.getElementById('t_cost_breakdown').textContent=t('cost_breakdown');
  document.getElementById('t_sights').textContent=t('sights');
  document.getElementById('t_hotels').textContent=t('hotels');
  document.getElementById('t_hazards').textContent=t('hazards');
  document.getElementById('t_route_box').textContent=t('route_box');
  const gyg = document.getElementById('gyg');
  if(gyg && (gyg.textContent||'').includes('Bitte Analyse ausführen')) gyg.textContent = t('gyg_loading');
}
function qs(id){return document.getElementById(id)}
function fmtEuro(n){return (n==null||isNaN(n))?'–':'€'+Number(n).toLocaleString(LANG==='de'?'de-DE':'en-US')}
let map=null, markers=[], routeReady=false;

function condText(row){
  if(LANG==='en' && row.condition_en){ return row.condition_en; }
  return row.condition;
}

// *** Hier ist die neue Map-Logik: nur EINE Tilequelle, kein Misch-Masch mehr ***
function ensureMap(){
  if(!map){
    const useMTK = (HAS_MAPTOOLKIT === true || HAS_MAPTOOLKIT === "true");

    const tiles = useMTK
      ? ['/tiles/{z}/{x}/{y}.png']                          // nur MapToolKit
      : ['https://tile.openstreetmap.org/{z}/{x}/{y}.png']; // nur OSM

    const attribution = useMTK
      ? '© MapToolKit'
      : '© OpenStreetMap contributors';

    map = new maplibregl.Map({
      container: 'map',
      style: {
        "version": 8,
        "sources": {
          "raster-tiles": {
            "type": "raster",
            "tiles": tiles,
            "tileSize": 256,
            "attribution": attribution
          }
        },
        "layers": [
          { "id": "base", "type": "raster", "source": "raster-tiles" }
        ]
      },
      center: [10,50],
      zoom: 4
    });

    map.on('load', ()=>{
      map.addSource('route', {
        type:'geojson',
        data: {"type":"FeatureCollection","features":[]}
      });
      map.addLayer({
        id:'route-line',
        type:'line',
        source:'route',
        paint:{
          'line-width':3,
          'line-color':'#4fc3f7'
        }
      });
      routeReady = true;
    });
  }
  return true;
}

function drawRoute(coords){
  if(!map) return;
  const data={"type":"FeatureCollection","features":[{"type":"Feature","geometry":{"type":"LineString","coordinates":coords}}]};
  const act=()=>{ map.getSource('route').setData(data); map.fitBounds(new maplibregl.LngLatBounds(coords[0], coords[coords.length-1]), {padding:50}); };
  routeReady ? act() : map.once('load', ()=>{routeReady=true; act();});
}
function setMarkers(rows){
  markers.forEach(m=>m.remove()); markers=[];
  const bounds = new maplibregl.LngLatBounds();
  const origin = qs('origin').value, mode = qs('mode').value;

  rows.forEach((r,i)=>{
    const el = document.createElement('div');
    el.style.cssText='background:#4fc3f7;width:12px;height:12px;border-radius:50%;border:2px solid #0b1324';
    let distanceLine = '';
    if(origin && r.travel && r.travel.distance_km!=null) {
      const carOrTrain = (mode==='car' || mode==='train');
      distanceLine = carOrTrain
        ? `<br>${t('drive')}: ${r.travel.distance_km} km · ${r.travel.time_h} h · ${fmtEuro(r.travel.cost_eur)}`
        : `<br>${t('flight')}: ${r.travel.distance_km} km · ${r.travel.time_h} h`;
    }
    const popupHTML = `<b>${r.destination}</b><br>Score: ${r.score}<br>${r.season_temp.toFixed(1)}°C · ${condText(r)}<br>${fmtEuro(r.cost_ppd)}/Tag p.P.${distanceLine}<br><br><button id="d_${i}" class="btn2">${t('details')}</button>`;
    const m = new maplibregl.Marker(el).setLngLat([r.lon, r.lat]).setPopup(new maplibregl.Popup().setHTML(popupHTML)).addTo(map);
    m.getElement().addEventListener('click',()=>setTimeout(()=>{
      const b=document.getElementById('d_'+i);
      if(b){ b.onclick=()=>{ openDetails(r); loadGYG(r.destination, r.lat, r.lon); loadHazards(r.country); }; }
    }, 80));
    markers.push(m); bounds.extend([r.lon, r.lat]);
  });
  if(rows.length===1){ map.flyTo({center:[rows[0].lon, rows[0].lat], zoom:8}); }
  else if(rows.length>1){ map.fitBounds(bounds, {padding:40}); }
}
function renderTable(rows){
  const tb=qs('tbl').querySelector('tbody'); tb.innerHTML='';
  rows.forEach((r,i)=>{
    const tr=document.createElement('tr');
    const btnDet=document.createElement('button'); btnDet.className='btn2'; btnDet.textContent=t('details');
    btnDet.onclick=()=>{ openDetails(r); loadGYG(r.destination, r.lat, r.lon); loadHazards(r.country); };
    const tdBtn=document.createElement('td'); tdBtn.appendChild(btnDet);
    const btnRoute=document.createElement('button'); btnRoute.className='btn2'; btnRoute.textContent=t('route');
    btnRoute.onclick=()=>showRouteTo(r);
    const tdRoute=document.createElement('td'); tdRoute.appendChild(btnRoute);
    const distTxt = (r.travel && r.travel.distance_km!=null) ? (r.travel.distance_km+' km') : '–';
    tr.innerHTML=`<td>${i+1}</td><td>${r.destination}</td><td>${r.score}</td>
      <td style="text-align:right">${r.season_temp.toFixed(1)}°C</td>
      <td>${condText(r)}</td><td style="text-align:right">${fmtEuro(r.cost_ppd)}</td>
      <td style="text-align:right">${fmtEuro(r.budget_total)}</td>
      <td style="text-align:right">${distTxt}</td>`;
    tr.appendChild(tdBtn); tr.appendChild(tdRoute); tb.appendChild(tr);
  });
}
function toggleDetails(show){ document.getElementById('details').style.display = show ? 'block' : 'none'; }

function fillCosts(row){
  const c = row.costs || {stay:null,travel:null,activities:null,total:null};
  const det = document.getElementById('detCosts');
  det.innerHTML = `
    <div>🏨 Unterkunft</div><div>${fmtEuro(c.stay)}</div>
    <div>🚀 Anreise</div><div>${fmtEuro(c.travel)}</div>
    <div>🎟️ Aktivitäten</div><div>${fmtEuro(c.activities)}</div>
    <div><b>Σ Gesamt</b></div><b>${fmtEuro(c.total)}</b>
  `;

  const explainEl = document.getElementById('detCostExplain');
  const meta = row.meta || {};
  const nights = meta.nights;
  const adults = meta.adults;
  const actppd = meta.actppd;
  const hotelDesc = row.hotel_desc || "Hotelkategorie nach Preisbereich (Schätzung)";
  const tData = row.travel || {};
  const mode = document.getElementById('mode').value;

  let parts = [];

  if(c.stay != null && !isNaN(c.stay)){
    if(nights && adults){
      parts.push(`🏨 Unterkunft: ca. ${fmtEuro(c.stay)} für ${nights} Nacht/Nächte und ${adults} Person(en) (Ø ${fmtEuro(row.cost_ppd)} pro Person & Nacht, ${hotelDesc}).`);
    } else {
      parts.push(`🏨 Unterkunft: ca. ${fmtEuro(c.stay)} (Ø ${fmtEuro(row.cost_ppd)} pro Person & Nacht, ${hotelDesc}).`);
    }
  }

  if(c.travel != null && !isNaN(c.travel)){
    const oneWay = (tData.oneway_cost_eur != null && !isNaN(tData.oneway_cost_eur))
      ? tData.oneway_cost_eur
      : c.travel/2;
    let modeLabel = "Reise";
    if(mode === "flight") modeLabel = "Flug";
    else if(mode === "train") modeLabel = "Zug";
    else if(mode === "car") modeLabel = "Anreise mit dem Auto";
    const distTxt = (tData.distance_km != null) ? `${tData.distance_km} km` : "–";
    const timeTxt = (tData.time_h != null) ? `${tData.time_h} h` : "–";
    parts.push(`🚀 Anreise & Rückreise: ca. ${fmtEuro(c.travel)} insgesamt (≈ ${fmtEuro(oneWay)} je Strecke, ${modeLabel}, Distanz ca. ${distTxt}, Reisezeit ca. ${timeTxt}).`);
  } else {
    parts.push("🚀 Anreise & Rückreise: Keine verlässliche Kostenschätzung möglich (Startort oder Modus fehlen).");
  }

  if(c.activities != null && !isNaN(c.activities)){
    if(actppd && nights && adults){
      parts.push(`🎟️ Aktivitäten: ca. ${fmtEuro(c.activities)} insgesamt (≈ ${fmtEuro(actppd)} pro Person & Tag, typischerweise Eintritte, kleine Touren, Ausflüge oder Restaurantbesuche).`);
    } else {
      parts.push(`🎟️ Aktivitäten: ca. ${fmtEuro(c.activities)} (geschätztes Budget für Ausflüge, Eintritte & Freizeitprogramm).`);
    }
  }

  if(explainEl){
    explainEl.innerHTML = parts.map(p => `<p>${p}</p>`).join("");
  }

  const links = document.getElementById('detCostLinks');
  const l=row.links||{};
  const btn = (label, url)=> url? `<a class="btn2" target="_blank" href="${url}">${label}</a>`:'';
  links.innerHTML = [
    btn("Hotels (Booking)", l.stay),
    btn("Anreise", l.travel),
    btn("Aktivitäten / Inspiration", l.activities),
    btn(t("fotos"), l.photos)
  ].filter(Boolean).join('');
}

async function openDetails(row){
  document.getElementById('detTitle').textContent = row.destination;
  document.getElementById('detMeta').textContent =
    `≈${row.season_temp.toFixed(1)}°C · ${condText(row)} · ${fmtEuro(row.cost_ppd)}/Tag p.P. · ${t('total')}: ${fmtEuro(row.budget_total)}`;
  document.getElementById('detSights').innerHTML = '…';
  document.getElementById('detHotels').innerHTML='…';
  document.getElementById('detHazards').innerHTML='…';
  fillCosts(row);
  toggleDetails(true);

  try{
    const sr = await fetch('/api/sights', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({city: row.destination})
    });
    const data = await sr.json();
    document.getElementById('detSights').innerHTML =
      (data.sights||[]).map(s=>`<div class="sight">• ${s}</div>`).join('') || '–';
  } catch(e){
    document.getElementById('detSights').textContent='Fehler beim Laden';
  }

  try{
    const ci=document.getElementById('checkin').value,
          co=document.getElementById('checkout').value,
          ad=Number(document.getElementById('adults').value||2);
    const hr = await fetch('/api/hotels', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({city: row.destination, checkin: ci, checkout: co, adults: ad})
    });
    const data = await hr.json();
    const list=(data.hotels||[]).map(h=>{
      const sc=(h.review_score!=null && !isNaN(h.review_score))
        ? `<span class="badge" style="background:#1f3a2a">${Number(h.review_score).toFixed(1)}</span>`:'';
      const typ=h.type?` <span class="badge">${h.type}</span>`:'';
      return `<div class="hotel"><span>${h.name}${typ} ${sc}</span><span>${fmtEuro(h.price_per_night)}</span></div>`;
    }).join('');
    document.getElementById('detHotels').innerHTML=list || '–';
  } catch(e){
    document.getElementById('detHotels').textContent='Fehler beim Laden';
  }
}

async function loadHazards(country){
  try{
    const r = await fetch('/api/hazards', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({country})
    });
    const data = await r.json();
    const itemsHtml = (data.items||[]).map(h=>
      `<div class="sight">• <b>${h.risk}</b> (${h.season}) – ${h.advice}</div>`
    ).join('') || '–';

    let linkHtml = '';
    if(data.link){
      linkHtml = `<div style="margin-top:10px"><a class="btn2" target="_blank" href="${data.link}">${t('aa_link')}</a></div>`;
    }

    document.getElementById('detHazards').innerHTML = itemsHtml + linkHtml;
  }catch(e){
    document.getElementById('detHazards').textContent='Fehler beim Laden';
  }
}

async function showRouteTo(row){
  const origin = document.getElementById('origin').value;
  const mode = document.getElementById('mode').value;
  if(!origin){
    alert(LANG==='de'?'Bitte Startort eingeben.':'Please enter origin.');
    return;
  }
  try{
    const r = await fetch('/api/route', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({origin, dest:{lat:row.lat, lon:row.lon}, mode})
    });
    const data = await r.json();
    if(data.coords){ drawRoute(data.coords); }
    let base = `${t('dist')}: ${data.distance_km} km · ${data.time_h} h · ${fmtEuro(data.cost_eur)}`;
    if(mode!=='car' && data.suggested && data.suggested.name){
      base += `\n${LANG==='de'?'Vorgeschlagener Abfahrtsort':'Suggested departure'}: ${data.suggested.name}`;
    }
    document.getElementById('routeSummary').textContent = base.replace('\\n',' | ');
    alert(base);
  }catch(e){
    alert(LANG==='de'?'Route konnte nicht berechnet werden.':'Route failed.');
  }
}

function gygCard(item){
  const price = item.price_eur!=null ? ` · ${fmtEuro(item.price_eur)}` : '';
  return `<a href="${item.url}" target="_blank" class="btn2" style="margin:6px 6px 0 0; display:inline-block">${item.title}${price}</a>`;
}
async function loadGYG(destination, lat, lon){
  document.getElementById('gyg').innerHTML=t('gyg_loading');
  document.getElementById('gygCity').textContent = destination;
  try{
    const r = await fetch('/api/guides',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({destination, lat, lon})
    });
    const data = await r.json();
    const items = (data.items||[]);
    let html = items.map(it=>gygCard(it)).join('');
    const photoBtn = `<a class="btn2" target="_blank" href="${encodeURI('https://www.google.com/search?tbm=isch&q='+destination)}" style="margin:6px 6px 0 0; display:inline-block">${t('fotos')}</a>`;
    html += photoBtn;
    document.getElementById('gyg').innerHTML = html || photoBtn;
  }catch(e){
    document.getElementById('gyg').textContent='Fehler beim Laden';
  }
}

function fillCurrencySelects(){
  const from=document.getElementById('fx_from'), to=document.getElementById('fx_to');
  from.innerHTML = CURRENCIES.map(c=>`<option ${c==='EUR'?'selected':''}>${c}</option>`).join('');
  to.innerHTML   = CURRENCIES.map(c=>`<option ${c==='USD'?'selected':''}>${c}</option>`).join('');
}

async function analyze(){
  const payload = {
    checkin: document.getElementById('checkin').value,
    checkout: document.getElementById('checkout').value,
    adults: Number(document.getElementById('adults').value||2),
    budget: Number(document.getElementById('budget').value||150),
    tmin: Number(document.getElementById('tmin').value||18),
    tmax: Number(document.getElementById('tmax').value||28),
    triptype: document.getElementById('triptype').value,
    origin: document.getElementById('origin').value,
    mode: document.getElementById('mode').value,
    actppd: Number(document.getElementById('actppd').value||0)
  };
  try{
    const r = await fetch('/api/analyze', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(payload)
    });
    const data = await r.json();

    const onlyTop = document.getElementById('onlytop').value === '1';
    const rows = onlyTop ? data.rows.slice(0,3) : data.rows;

    renderTable(rows);

    document.getElementById('kpiCount').textContent =
      onlyTop ? `${rows.length} / ${data.rows.length}` : `${data.rows.length}`;

    const ci = payload.checkin || '–', co = payload.checkout || '–';
    document.getElementById('kpiFilters').textContent =
      `${LANG==='de'?'Check-in':'Check-in'}: ${ci} · ${LANG==='de'?'Check-out':'Check-out'}: ${co} · ${LANG==='de'?'Personen':'People'}: ${payload.adults} · ${t('budget_ppd')}: ${fmtEuro(payload.budget)} · ${LANG==='de'?'Wunsch-Temp':'Target temp'}: ${payload.tmin}–${payload.tmax}°C · ${t('triptype')}: ${payload.triptype} · ${LANG==='de'?'Start':'Origin'}: ${payload.origin||'–'} (${payload.mode}) · ${t('actppd')}: ${fmtEuro(payload.actppd)}`;

    if(rows.length){
      const b=rows[0];
      document.getElementById('bestTitle').textContent = `${b.destination} (Score ${b.score})`;
      document.getElementById('bestMeta').textContent =
        `≈${b.season_temp.toFixed(1)}°C · ${condText(b)} · ${fmtEuro(b.cost_ppd)}/Tag p.P. · ${t('total')}: ${fmtEuro(b.budget_total)}`;
      if(b.travel && b.travel.distance_km!=null){
        let txt = `${t('dist')}: ${b.travel.distance_km} km · ${b.travel.time_h} h · ${fmtEuro(b.travel.cost_eur)}`;
        if(b.suggested && b.suggested.name){
          txt += ` · ${LANG==='de'?'Abfahrt':'Departure'}: ${b.suggested.name}`;
        }
        document.getElementById('routeSummary').textContent = txt;
      } else {
        document.getElementById('routeSummary').textContent =
          LANG==='de'?'Bitte Startort (z.B. Berlin, München) eingeben, um Routen zu sehen.':'Enter origin to see routes.';
      }
      loadGYG(b.destination, b.lat, b.lon);
      if(ensureMap()){ setMarkers(rows); }
    } else {
      document.getElementById('bestTitle').textContent='–';
      document.getElementById('bestMeta').textContent='–';
      document.getElementById('routeSummary').textContent='–';
      document.getElementById('gyg').textContent=t('gyg_loading');
      document.getElementById('gygCity').textContent='–';
    }
  }catch(e){
    alert(LANG==='de'?'Analyse fehlgeschlagen.':'Analysis failed.');
  }
}

document.getElementById('runBtn').addEventListener('click', analyze);
document.getElementById('langSel').addEventListener('change', (e)=>{
  LANG=e.target.value;
  applyLang();
  analyze();
});
document.addEventListener('DOMContentLoaded', ()=>{
  ensureMap();
  fillCurrencySelects();
  applyLang();
  analyze();
});

document.getElementById('fxBtn').addEventListener('click', async ()=>{
  const amount = Number(document.getElementById('fx_amount').value)||0,
        frm=(document.getElementById('fx_from').value||'EUR').trim().toUpperCase(),
        to =(document.getElementById('fx_to').value||'USD').trim().toUpperCase();
  const out=document.getElementById('fx_out'); out.textContent='…';
  try{
    const r = await fetch('/api/convert', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({amount, frm, to})
    });
    const data = await r.json();
    out.textContent = (data && typeof data.result==='number')
      ? `${amount} ${frm} = ${data.result.toFixed(4)} ${to}`
      : (data.error||t('fx_failed'));
  }catch(e){
    out.textContent=t('fx_failed');
  }
});

document.getElementById('aiBtn').addEventListener('click', async ()=>{
  const q = (document.getElementById('aiq').value||'').trim();
  const out=document.getElementById('aiOut');
  if(!q){ out.textContent=t('ai_enter'); return; }
  out.textContent='…';
  try{
    const r = await fetch('/api/ask', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({q})
    });
    const data = await r.json();
    out.textContent = data.text || (data.error || '–');
  }catch(e){
    out.textContent='Fehler';
  }
});
</script>
</body></html>
"""
