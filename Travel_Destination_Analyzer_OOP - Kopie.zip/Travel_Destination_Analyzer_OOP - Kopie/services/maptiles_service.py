# services/maptiles_service.py
from __future__ import annotations
from urllib import request
from config import SSL_CTX, MAPTOOLKIT_RAPIDAPI_KEY, MAPTOOLKIT_RAPIDAPI_HOST, MAPTOOLKIT_RAPIDAPI_PATH_TEMPLATE

class MapTilesService:
    def fetch_tile_png(self, z: int, x: int, y: int) -> bytes | None:
        if not (MAPTOOLKIT_RAPIDAPI_KEY and MAPTOOLKIT_RAPIDAPI_HOST):
            return None
        path = MAPTOOLKIT_RAPIDAPI_PATH_TEMPLATE.format(z=z, x=x, y=y)
        url = f"https://{MAPTOOLKIT_RAPIDAPI_HOST}{path}"
        headers = {
            "User-Agent": "travel-webapp/1.0",
            "x-rapidapi-key": MAPTOOLKIT_RAPIDAPI_KEY,
            "x-rapidapi-host": MAPTOOLKIT_RAPIDAPI_HOST,
        }
        try:
            req = request.Request(url, headers=headers)
            with request.urlopen(req, context=SSL_CTX, timeout=30) as resp:
                if resp.status != 200:
                    return None
                return resp.read()
        except Exception:
            return None
