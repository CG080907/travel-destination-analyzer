# services/hazards_service.py
from __future__ import annotations
from urllib.parse import quote_plus
from .destinations_data import HAZARDS, COUNTRY_NAME_DE

class HazardsService:
    def get_hazards(self, country_code: str) -> list[dict]:
        return HAZARDS.get(country_code.upper(), [])

    def get_aa_link(self, country_code: str) -> str | None:
        cc = country_code.upper()
        name = COUNTRY_NAME_DE.get(cc)
        if not name:
            return None
        q = quote_plus(name)
        return f"https://www.auswaertiges-amt.de/de/ReiseUndSicherheit"
