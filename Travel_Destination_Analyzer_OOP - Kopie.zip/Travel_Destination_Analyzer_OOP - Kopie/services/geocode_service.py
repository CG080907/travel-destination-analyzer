# services/geocode_service.py
from __future__ import annotations
from typing import Tuple
from urllib.parse import urlencode
from urllib import request
import json
from config import SSL_CTX
from .destinations_data import ORIGIN_POINTS

class GeocodeService:
    def http_get_json(self, url: str) -> dict:
        req = request.Request(url, headers={"User-Agent":"travel-webapp/1.0"})
        with request.urlopen(req, context=SSL_CTX, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8") or "{}")

    def geocode_freeform(self, query: str) -> tuple[float|None, float|None]:
        if not query:
            return (None, None)
        url = "https://nominatim.openstreetmap.org/search?" + urlencode({
            "format":"json",
            "limit": 1,
            "q": query,
        })
        try:
            data = self.http_get_json(url)
            if isinstance(data, list) and data:
                d0 = data[0]
                lat = float(d0.get("lat"))
                lon = float(d0.get("lon"))
                return (lat, lon)
        except Exception:
            pass
        return (None, None)

    def resolve_origin(self, query: str) -> tuple[float|None, float|None, str|None]:
        if not query:
            return (None, None, None)
        key_norm = query.strip().lower()
        val = ORIGIN_POINTS.get(key_norm)
        if not val:
            first = key_norm.split(",")[0].strip()
            val = ORIGIN_POINTS.get(first)
        if val:
            return val

        lat, lon = self.geocode_freeform(query)
        if lat is not None and lon is not None:
            pretty = query.strip()
            return (lat, lon, pretty or None)

        return (None, None, query.strip() or None)
