# services/destinations_data.py
from __future__ import annotations

def city_key(full: str) -> str:
    return full.split(",")[0].strip()

# -------------------------------------------------------------
# Reiseziele
# -------------------------------------------------------------
# Alle von dir gewünschten Orte sind enthalten:
# - Strandurlaub
# - Familienurlaub
# - Wandern & Outdoor
# - Citytrip
# - Skifahren
# - Naturreisen
# - Entspannung & Wellness
# - Sightseeing & Kultur
# - Partyurlaub
#
# Zusätzlich ein paar sinnvolle Ergänzungen, aber nichts
# davon stört deine Logik.
# -------------------------------------------------------------
DESTINATIONS = [
    # ---------- Strandurlaub ----------
    {"name":"Mallorca, ES",            "lat":39.6953, "lon":3.0176,   "avg_cost_per_day":130,
     "tags":["strand","familie","party","wellness","natur"], "country":"ES"},
    {"name":"Ibiza, ES",               "lat":38.9067, "lon":1.4206,   "avg_cost_per_day":160,
     "tags":["strand","party","city"], "country":"ES"},
    {"name":"Menorca, ES",             "lat":39.9496, "lon":4.1100,   "avg_cost_per_day":120,
     "tags":["strand","familie","wellness"], "country":"ES"},
    {"name":"Costa del Sol, ES",       "lat":36.7213, "lon":-4.4213,  "avg_cost_per_day":120,
     "tags":["strand","familie","city"], "country":"ES"},
    {"name":"Algarve, PT",             "lat":37.0194, "lon":-7.9304,  "avg_cost_per_day":110,
     "tags":["strand","familie","wellness","natur"], "country":"PT"},
    {"name":"Madeira, PT",             "lat":32.6669, "lon":-16.9241, "avg_cost_per_day":130,
     "tags":["natur","outdoor","wellness","strand"], "country":"PT"},
    {"name":"Azoren, PT",              "lat":37.7412, "lon":-25.6756, "avg_cost_per_day":120,
     "tags":["natur","outdoor","strand"], "country":"PT"},
    {"name":"Sardinien, IT",           "lat":39.2238, "lon":9.1217,   "avg_cost_per_day":150,
     "tags":["strand","natur","wellness"], "country":"IT"},
    {"name":"Sizilien, IT",            "lat":38.1157, "lon":13.3615,  "avg_cost_per_day":130,
     "tags":["strand","kultur","natur","resort"], "country":"IT"},
    {"name":"Amalfiküste, IT",         "lat":40.6340, "lon":14.6020,  "avg_cost_per_day":180,
     "tags":["strand","kultur","wellness","natur"], "country":"IT"},
    {"name":"Kreta, GR",               "lat":35.3387, "lon":25.1442,  "avg_cost_per_day":110,
     "tags":["strand","outdoor","familie"], "country":"GR"},
    {"name":"Rhodos, GR",              "lat":36.4343, "lon":28.2176,  "avg_cost_per_day":110,
     "tags":["strand","familie","kultur"], "country":"GR"},
    {"name":"Mykonos, GR",             "lat":37.4467, "lon":25.3289,  "avg_cost_per_day":180,
     "tags":["strand","party"], "country":"GR"},
    {"name":"Santorini, GR",           "lat":36.3932, "lon":25.4615,  "avg_cost_per_day":180,
     "tags":["strand","kultur","wellness","romantik"], "country":"GR"},
    {"name":"Dubrovnik Riviera, HR",   "lat":42.6507, "lon":18.0944,  "avg_cost_per_day":140,
     "tags":["strand","kultur","natur"], "country":"HR"},

    # ---------- Familienurlaub ----------
    {"name":"Gardasee, IT",            "lat":45.6000, "lon":10.7000,  "avg_cost_per_day":140,
     "tags":["familie","natur","outdoor","strand"], "country":"IT"},
    {"name":"Toskana, IT",             "lat":43.7711, "lon":11.2486,  "avg_cost_per_day":150,
     "tags":["familie","kultur","natur","wellness"], "country":"IT"},
    {"name":"Cinque Terre, IT",        "lat":44.1200, "lon":9.7100,   "avg_cost_per_day":160,
     "tags":["familie","strand","outdoor","kultur"], "country":"IT"},
    {"name":"Barcelona, ES",           "lat":41.3851, "lon":2.1734,   "avg_cost_per_day":150,
     "tags":["city","strand","party","kultur","familie"], "country":"ES"},
    {"name":"Valencia, ES",            "lat":39.4699, "lon":-0.3763,  "avg_cost_per_day":130,
     "tags":["familie","city","strand"], "country":"ES"},
    {"name":"Kanaren, ES",             "lat":28.3000, "lon":-16.6000, "avg_cost_per_day":130,
     "tags":["familie","strand","natur"], "country":"ES"},
    {"name":"Bretagne, FR",            "lat":48.4000, "lon":-4.5000,  "avg_cost_per_day":130,
     "tags":["familie","strand","natur"], "country":"FR"},
    {"name":"Provence, FR",            "lat":43.9300, "lon":4.8200,   "avg_cost_per_day":150,
     "tags":["familie","natur","kultur","wellness"], "country":"FR"},
    {"name":"Kopenhagen, DK",          "lat":55.6761, "lon":12.5683,  "avg_cost_per_day":200,
     "tags":["city","familie","kultur"], "country":"DK"},
    {"name":"Amsterdam, NL",           "lat":52.3676, "lon":4.9041,   "avg_cost_per_day":180,
     "tags":["city","party","kultur","familie"], "country":"NL"},
    {"name":"Luzern, CH",              "lat":47.0500, "lon":8.3100,   "avg_cost_per_day":200,
     "tags":["familie","natur","city"], "country":"CH"},
    {"name":"Schwarzwald, DE",         "lat":48.3000, "lon":8.2000,   "avg_cost_per_day":120,
     "tags":["familie","natur","outdoor"], "country":"DE"},
    {"name":"Ostseeinseln, DE",        "lat":54.4000, "lon":13.4000,  "avg_cost_per_day":110,
     "tags":["familie","strand","natur"], "country":"DE"},
    {"name":"Cornwall, GB",            "lat":50.4000, "lon":-4.7000,  "avg_cost_per_day":150,
     "tags":["familie","strand","natur"], "country":"GB"},
    {"name":"Lissabon, PT",            "lat":38.7223, "lon":-9.1393,  "avg_cost_per_day":130,
     "tags":["city","strand","kultur","familie"], "country":"PT"},

    # ---------- Wandern & Outdoor ----------
    {"name":"Lofoten, NO",             "lat":68.3000, "lon":14.7000,  "avg_cost_per_day":170,
     "tags":["natur","outdoor"], "country":"NO"},
    {"name":"Geirangerfjord, NO",      "lat":62.1000, "lon":7.2000,   "avg_cost_per_day":160,
     "tags":["natur","outdoor"], "country":"NO"},
    {"name":"Dolomiten, IT",           "lat":46.4000, "lon":11.8000,  "avg_cost_per_day":160,
     "tags":["natur","outdoor","ski"], "country":"IT"},
    {"name":"Interlaken, CH",          "lat":46.6863, "lon":7.8632,   "avg_cost_per_day":190,
     "tags":["natur","outdoor","abenteuer"], "country":"CH"},
    {"name":"Zermatt, CH",             "lat":46.0207, "lon":7.7491,   "avg_cost_per_day":220,
     "tags":["ski","outdoor","natur"], "country":"CH"},
    {"name":"Island – Golden Circle, IS", "lat":64.2500,"lon":-21.0000,"avg_cost_per_day":190,
     "tags":["natur","outdoor"], "country":"IS"},
    {"name":"Plitvicer Seen, HR",      "lat":44.8800, "lon":15.6200,  "avg_cost_per_day":130,
     "tags":["natur","outdoor"], "country":"HR"},
    {"name":"Bled, SI",                "lat":46.3700, "lon":14.1100,  "avg_cost_per_day":130,
     "tags":["natur","outdoor"], "country":"SI"},

    # ---------- Citytrip ----------
    {"name":"Paris, FR",               "lat":48.8566, "lon":2.3522,   "avg_cost_per_day":190,
     "tags":["city","kultur"], "country":"FR"},
    {"name":"London, GB",              "lat":51.5074, "lon":-0.1278,  "avg_cost_per_day":200,
     "tags":["city","kultur","party"], "country":"GB"},
    {"name":"Berlin, DE",              "lat":52.5200, "lon":13.4050,  "avg_cost_per_day":130,
     "tags":["city","party"], "country":"DE"},
    {"name":"Rom, IT",                 "lat":41.9028, "lon":12.4964,  "avg_cost_per_day":160,
     "tags":["city","kultur"], "country":"IT"},
    {"name":"Wien, AT",                "lat":48.2082, "lon":16.3738,  "avg_cost_per_day":160,
     "tags":["city","kultur"], "country":"AT"},
    {"name":"Prag, CZ",                "lat":50.0755, "lon":14.4378,  "avg_cost_per_day":110,
     "tags":["city","kultur","party"], "country":"CZ"},
    {"name":"Budapest, HU",            "lat":47.4979, "lon":19.0402,  "avg_cost_per_day":100,
     "tags":["city","party","wellness"], "country":"HU"},
    {"name":"Madrid, ES",              "lat":40.4168, "lon":-3.7038,  "avg_cost_per_day":140,
     "tags":["city","kultur"], "country":"ES"},
    {"name":"Stockholm, SE",           "lat":59.3293, "lon":18.0686,  "avg_cost_per_day":190,
     "tags":["city","natur"], "country":"SE"},
    {"name":"Dublin, IE",              "lat":53.3498, "lon":-6.2603,  "avg_cost_per_day":170,
     "tags":["city","party"], "country":"IE"},
    {"name":"Istanbul, TR",            "lat":41.0082, "lon":28.9784,  "avg_cost_per_day":90,
     "tags":["city","kultur"], "country":"TR"},

    # ---------- Skifahren ----------
    {"name":"Verbier, CH",             "lat":46.1000, "lon":7.2330,   "avg_cost_per_day":230,
     "tags":["ski","outdoor","natur"], "country":"CH"},
    {"name":"St. Moritz, CH",          "lat":46.4900, "lon":9.8350,   "avg_cost_per_day":240,
     "tags":["ski","outdoor","natur","wellness"], "country":"CH"},
    {"name":"Innsbruck, AT",           "lat":47.2692, "lon":11.4041,  "avg_cost_per_day":170,
     "tags":["ski","city","outdoor"], "country":"AT"},
    {"name":"Sölden, AT",              "lat":46.9700, "lon":10.9830,  "avg_cost_per_day":180,
     "tags":["ski","outdoor","natur"], "country":"AT"},
    {"name":"Kitzbühel, AT",           "lat":47.4460, "lon":12.3920,  "avg_cost_per_day":190,
     "tags":["ski","outdoor","natur"], "country":"AT"},
    {"name":"Garmisch-Partenkirchen, DE","lat":47.4940,"lon":11.0960,"avg_cost_per_day":170,
     "tags":["ski","outdoor","natur"], "country":"DE"},
    {"name":"Dolomiti Superski, IT",   "lat":46.5500, "lon":11.7600,  "avg_cost_per_day":190,
     "tags":["ski","outdoor","natur"], "country":"IT"},
    {"name":"Chamonix, FR",            "lat":45.9237, "lon":6.8694,   "avg_cost_per_day":190,
     "tags":["ski","outdoor","natur"], "country":"FR"},
    {"name":"Courchevel, FR",          "lat":45.4140, "lon":6.6320,   "avg_cost_per_day":220,
     "tags":["ski","outdoor","natur","luxus"], "country":"FR"},

    # ---------- Naturreisen ----------
    {"name":"Island – Blaue Lagune, IS","lat":63.8800,"lon":-22.4400, "avg_cost_per_day":200,
     "tags":["natur","outdoor","wellness"], "country":"IS"},
    {"name":"Lake District, GB",       "lat":54.5000, "lon":-3.0000,  "avg_cost_per_day":150,
     "tags":["natur","outdoor"], "country":"GB"},
    {"name":"Sächsische Schweiz, DE",  "lat":50.9200, "lon":14.1500,  "avg_cost_per_day":120,
     "tags":["natur","outdoor"], "country":"DE"},
    {"name":"Fjordnorwegen, NO",       "lat":61.0000, "lon":7.0000,   "avg_cost_per_day":170,
     "tags":["natur","outdoor"], "country":"NO"},
    {"name":"Lappland, FI",            "lat":67.9000, "lon":20.5000,  "avg_cost_per_day":160,
     "tags":["natur","outdoor","winter"], "country":"FI"},
    {"name":"Highlands, GB",           "lat":57.1000, "lon":-4.7000,  "avg_cost_per_day":150,
     "tags":["natur","outdoor"], "country":"GB"},
    {"name":"Durmitor Nationalpark, ME","lat":43.1300,"lon":19.0000,  "avg_cost_per_day":110,
     "tags":["natur","outdoor"], "country":"ME"},

    # ---------- Entspannung & Wellness ----------
    {"name":"Côte d’Azur, FR",         "lat":43.5500, "lon":7.0200,   "avg_cost_per_day":190,
     "tags":["strand","wellness","kultur"], "country":"FR"},
    {"name":"Südtirol, IT",            "lat":46.5000, "lon":11.3500,  "avg_cost_per_day":170,
     "tags":["natur","wellness","outdoor"], "country":"IT"},
    {"name":"Therme Erding, DE",       "lat":48.3000, "lon":11.9000,  "avg_cost_per_day":140,
     "tags":["wellness","familie"], "country":"DE"},
    {"name":"Züricher See, CH",        "lat":47.2600, "lon":8.6800,   "avg_cost_per_day":200,
     "tags":["wellness","natur","city"], "country":"CH"},
    {"name":"Thermen Slowenien, SI",   "lat":46.6500, "lon":16.2000,  "avg_cost_per_day":110,
     "tags":["wellness","familie"], "country":"SI"},
    # Mallorca & Madeira & Algarve & Sizilien sind oben schon drin, dort mit Wellness-/ruhig-Tags

    # ---------- Sightseeing & Kultur ----------
    {"name":"Athen, GR",               "lat":37.9838, "lon":23.7275,  "avg_cost_per_day":130,
     "tags":["city","kultur"], "country":"GR"},
    {"name":"Granada, ES",             "lat":37.1773, "lon":-3.5986,  "avg_cost_per_day":120,
     "tags":["city","kultur"], "country":"ES"},
    {"name":"Sevilla, ES",             "lat":37.3891, "lon":-5.9845,  "avg_cost_per_day":130,
     "tags":["city","kultur"], "country":"ES"},
    {"name":"Edinburgh, GB",           "lat":55.9533, "lon":-3.1883,  "avg_cost_per_day":170,
     "tags":["city","kultur"], "country":"GB"},
    {"name":"Krakau, PL",              "lat":50.0647, "lon":19.9450,  "avg_cost_per_day":100,
     "tags":["city","kultur"], "country":"PL"},
    {"name":"Brügge, BE",              "lat":51.2093, "lon":3.2247,   "avg_cost_per_day":150,
     "tags":["city","kultur"], "country":"BE"},

    # ---------- Partyurlaub ----------
    # (Viele sind oben schon als city/party markiert)
    # Ibiza, Mykonos, Mallorca, Berlin, Budapest usw.
]

# -------------------------------------------------------------
# Profile – welche Tags passen zu welchem Reisetyp?
# -------------------------------------------------------------
TRIP_PROFILES = {
    "familie":  ["familie","strand","city"],
    "strand":   ["strand"],
    "outdoor":  ["outdoor","natur"],
    "city":     ["city","kultur"],
    "ski":      ["ski"],
    "natur":    ["natur","outdoor"],
    "wellness": ["wellness"],
    "kultur":   ["kultur","city"],
    "party":    ["party","city"],
}

# -------------------------------------------------------------
# Risiken / Reisehinweise pro Land
# -------------------------------------------------------------
HAZARDS = {
    "FR":[
        {"risk":"Taschendiebstahl an Hotspots (Paris, Riviera)","season":"Ganzjährig, v. a. Hochsaison","advice":"Wertsachen nah am Körper; in Metro & Sehenswürdigkeiten aufmerksam."},
        {"risk":"Sommerhitze & UV (Juni–Aug)","season":"Sommer","advice":"Schattenpausen, Wasser, Sonnenschutz."},
    ],
    "DE":[
        {"risk":"Zecken in Wald-/Wiesenregionen","season":"Apr–Okt","advice":"Repellent, geschlossene Kleidung; nach Touren absuchen."},
    ],
    "ES":[
        {"risk":"Sonne/Hitze (Südküsten, Balearen, Kanaren)","season":"Mai–Sep","advice":"Hydration & Sonnenschutz; Mittagsstunden meiden."},
        {"risk":"Taschendiebstahl (Barcelona, Madrid, Küstenorte)","season":"Ganzjährig","advice":"Taschen geschlossen tragen; Menschenmengen beachten."},
    ],
    "IT":[
        {"risk":"Taschendiebstahl (Rom, Neapel, Mailand)","season":"Ganzjährig","advice":"Seriöse Anbieter; Achtung vor Trickbetrug."},
    ],
    "PT":[
        {"risk":"Atlantikbrandung an Stränden (Algarve, Madeira, Azoren)","season":"Ganzjährig","advice":"Flaggen beachten; nur bewachte Strände."},
    ],
    "GR":[
        {"risk":"Sonne/Hitze auf Inseln","season":"Sommer","advice":"Sonnenschutz, Wasser, Mittagsruhe beachten."},
    ],
    "NL":[
        {"risk":"Fahrradverkehr in Städten (Amsterdam)","season":"Ganzjährig","advice":"Auf Radwege achten; klare Handzeichen geben."},
    ],
    "AT":[
        {"risk":"Alpinrisiken (Wetterwechsel in den Alpen)","season":"Frühjahr–Herbst","advice":"Wetter prüfen; passende Ausrüstung."},
    ],
    "CZ":[
        {"risk":"Taschendiebstahl (Altstadt Prag)","season":"Hauptsaison","advice":"Wertsachen sichern; Bars/Wechselstuben prüfen."},
    ],
    "CH":[
        {"risk":"Alpinwetter & UV (Schweizer Alpen)","season":"Sommer/Winter","advice":"Zwiebellook, Sonnenschutz, Gewitterwarnungen."},
    ],
    "IS":[
        {"risk":"Raues Wetter, rutschige Küsten","season":"Ganzjährig","advice":"Warnhinweise beachten; sichere Wege."},
    ],
    "DK":[
        {"risk":"Fahrradverkehr (Kopenhagen)","season":"Ganzjährig","advice":"Auf Radwege achten; Fußgängerzonen respektieren."},
    ],
    "HU":[
        {"risk":"Thermen – Dehydrierung möglich","season":"Ganzjährig","advice":"Genug trinken; Zeit in heißen Becken begrenzen."},
    ],
    "HR":[
        {"risk":"Seeigel/Quallen (Adria)","season":"Sommer","advice":"Badeschuhe; lokale Hinweise beachten."},
    ],
    "GB":[
        {"risk":"Wechselhaftes Wetter, Regen","season":"Ganzjährig","advice":"Regenkleidung; rutschige Wege beachten."},
    ],
    "IE":[
        {"risk":"Starke Winde & Regen an der Küste","season":"Herbst/Winter","advice":"Klippenabsperrungen beachten; rutschfeste Schuhe."},
    ],
    "TR":[
        {"risk":"Starker Verkehr in Metropolen (Istanbul)","season":"Ganzjährig","advice":"Ampeln/Überwege nutzen; besonders vorsichtig beim Überqueren."},
    ],
    "SE":[
        {"risk":"Winterglätte & Dunkelheit","season":"Winter","advice":"Reflektoren; rutschfeste Schuhe; Straßenquerungen gut planen."},
    ],
    "PL":[
        {"risk":"Glatteis im Winter","season":"Winter","advice":"Rutschfeste Schuhe, vorsichtig gehen."},
    ],
    "BE":[
        {"risk":"Pflastersteine bei Nässe rutschig","season":"Herbst/Winter","advice":"Feste Schuhe, aufpassen in Altstädten."},
    ],
    "FI":[
        {"risk":"Extreme Kälte in Lappland","season":"Winter","advice":"Mehrschichtige Kleidung, Gesicht/Extremitäten schützen."},
    ],
    "ME":[
        {"risk":"Alpine Pfade in Durmitor","season":"Sommer","advice":"Nur markierte Wege, Wetter prüfen."},
    ],
    "NO":[
        {"risk":"Schneller Wetterwechsel in Fjorden/Bergen","season":"Frühjahr–Herbst","advice":"Zwiebellook, Notfallausrüstung bei Wanderungen."},
    ],
}

# -------------------------------------------------------------
# Länder-Namen für das Auswärtige Amt (Suchlink)
# -------------------------------------------------------------
COUNTRY_NAME_DE = {
    "DE":"Deutschland",
    "FR":"Frankreich",
    "ES":"Spanien",
    "PT":"Portugal",
    "IT":"Italien",
    "GR":"Griechenland",
    "GB":"Vereinigtes Königreich",
    "AT":"Österreich",
    "NL":"Niederlande",
    "CZ":"Tschechien",
    "CH":"Schweiz",
    "IS":"Island",
    "DK":"Dänemark",
    "HU":"Ungarn",
    "HR":"Kroatien",
    "IE":"Irland",
    "SE":"Schweden",
    "PL":"Polen",
    "BE":"Belgien",
    "FI":"Finnland",
    "ME":"Montenegro",
    "NO":"Norwegen",
    "SI":"Slowenien",
    "TR":"Türkei",
}

# -------------------------------------------------------------
# Flughäfen – erweitert (wichtige Hubs in Europa)
# -------------------------------------------------------------
AIRPORTS = [
    # Deutschland / DACH
    {"code":"FRA","name":"Frankfurt Airport","lat":50.0500,"lon":8.5700},
    {"code":"MUC","name":"Munich Airport","lat":48.3538,"lon":11.7861},
    {"code":"BER","name":"Berlin Brandenburg","lat":52.3667,"lon":13.5033},
    {"code":"HAM","name":"Hamburg Airport","lat":53.6320,"lon":9.9930},
    {"code":"DUS","name":"Düsseldorf Airport","lat":51.2895,"lon":6.7668},
    {"code":"CGN","name":"Köln/Bonn Airport","lat":50.8659,"lon":7.1427},
    {"code":"STR","name":"Stuttgart Airport","lat":48.6899,"lon":9.2219},
    {"code":"ZRH","name":"Zürich Airport","lat":47.4581,"lon":8.5555},
    {"code":"VIE","name":"Vienna International","lat":48.1103,"lon":16.5697},

    # Benelux & Frankreich
    {"code":"AMS","name":"Amsterdam Schiphol","lat":52.3086,"lon":4.7639},
    {"code":"CDG","name":"Paris Charles de Gaulle","lat":49.0097,"lon":2.5479},
    {"code":"ORY","name":"Paris Orly","lat":48.7233,"lon":2.3794},
    {"code":"BRU","name":"Brussels Airport","lat":50.9010,"lon":4.4856},

    # Spanien & Portugal
    {"code":"MAD","name":"Madrid Barajas","lat":40.4722,"lon":-3.5608},
    {"code":"BCN","name":"Barcelona El Prat","lat":41.2974,"lon":2.0833},
    {"code":"AGP","name":"Málaga (Costa del Sol)","lat":36.6749,"lon":-4.4991},
    {"code":"PMI","name":"Palma de Mallorca","lat":39.5517,"lon":2.7388},
    {"code":"IBZ","name":"Ibiza Airport","lat":38.8729,"lon":1.3731},
    {"code":"LPA","name":"Gran Canaria","lat":27.9319,"lon":-15.3866},
    {"code":"TFS","name":"Teneriffa Süd","lat":28.0445,"lon":-16.5725},
    {"code":"LIS","name":"Lisbon Airport","lat":38.7742,"lon":-9.1342},
    {"code":"OPO","name":"Porto Airport","lat":41.2481,"lon":-8.6814},
    {"code":"FNC","name":"Funchal (Madeira)","lat":32.6979,"lon":-16.7745},
    {"code":"PDL","name":"Ponta Delgada (Azoren)","lat":37.7412,"lon":-25.6979},

    # Italien & Griechenland
    {"code":"FCO","name":"Rome Fiumicino","lat":41.8003,"lon":12.2389},
    {"code":"LIN","name":"Milan Linate","lat":45.4600,"lon":9.2767},
    {"code":"MXP","name":"Milan Malpensa","lat":45.6306,"lon":8.7281},
    {"code":"VCE","name":"Venice Marco Polo","lat":45.5053,"lon":12.3519},
    {"code":"NAP","name":"Naples Airport","lat":40.8860,"lon":14.2908},
    {"code":"CAG","name":"Cagliari (Sardinien)","lat":39.2515,"lon":9.0543},
    {"code":"PMO","name":"Palermo (Sizilien)","lat":38.1811,"lon":13.0993},
    {"code":"CTA","name":"Catania (Sizilien)","lat":37.4668,"lon":15.0664},
    {"code":"ATH","name":"Athens Airport","lat":37.9364,"lon":23.9445},
    {"code":"HER","name":"Heraklion (Kreta)","lat":35.3397,"lon":25.1803},
    {"code":"RHO","name":"Rhodes Airport","lat":36.4054,"lon":28.0862},
    {"code":"JMK","name":"Mykonos Airport","lat":37.4351,"lon":25.3481},
    {"code":"JTR","name":"Santorini Airport","lat":36.4065,"lon":25.4793},

    # Skandinavien, UK, Osteuropa, Türkei
    {"code":"CPH","name":"Copenhagen Airport","lat":55.6180,"lon":12.6508},
    {"code":"ARN","name":"Stockholm Arlanda","lat":59.6519,"lon":17.9186},
    {"code":"OSL","name":"Oslo Gardermoen","lat":60.1976,"lon":11.1004},
    {"code":"HEL","name":"Helsinki Vantaa","lat":60.3172,"lon":24.9633},
    {"code":"LHR","name":"London Heathrow","lat":51.4700,"lon":-0.4543},
    {"code":"LGW","name":"London Gatwick","lat":51.1537,"lon":-0.1821},
    {"code":"DUB","name":"Dublin Airport","lat":53.4213,"lon":-6.2701},
    {"code":"PRG","name":"Prague Airport","lat":50.1008,"lon":14.26},
    {"code":"BUD","name":"Budapest Airport","lat":47.4370,"lon":19.2556},
    {"code":"KRK","name":"Kraków Airport","lat":50.0777,"lon":19.7848},
    {"code":"IST","name":"Istanbul Airport","lat":41.2753,"lon":28.7519},
]

# -------------------------------------------------------------
# Wichtige Bahn-Hubs (für Zugmodus)
# -------------------------------------------------------------
TRAIN_HUBS = [
    # Deutschland / DACH
    {"name":"Berlin Hbf","lat":52.5251,"lon":13.3694},
    {"name":"München Hbf","lat":48.1402,"lon":11.5586},
    {"name":"Frankfurt (Main) Hbf","lat":50.1071,"lon":8.6638},
    {"name":"Hamburg Hbf","lat":53.5526,"lon":10.0067},
    {"name":"Köln Hbf","lat":50.9429,"lon":6.9581},
    {"name":"Düsseldorf Hbf","lat":51.2190,"lon":6.7942},
    {"name":"Stuttgart Hbf","lat":48.7830,"lon":9.1820},
    {"name":"Wien Hbf","lat":48.1857,"lon":16.3740},
    {"name":"Zürich HB","lat":47.3782,"lon":8.5402},

    # Benelux & Frankreich
    {"name":"Paris Gare de l’Est","lat":48.8761,"lon":2.3589},
    {"name":"Paris Gare du Nord","lat":48.8809,"lon":2.3553},
    {"name":"Bruxelles-Midi","lat":50.8369,"lon":4.3370},
    {"name":"Amsterdam Centraal","lat":52.3791,"lon":4.9003},

    # Spanien & Portugal
    {"name":"Madrid Atocha","lat":40.4066,"lon":-3.6890},
    {"name":"Barcelona Sants","lat":41.3790,"lon":2.1400},
    {"name":"Lisboa Santa Apolónia","lat":38.7121,"lon":-9.1230},

    # Italien
    {"name":"Roma Termini","lat":41.9010,"lon":12.5018},
    {"name":"Milano Centrale","lat":45.4853,"lon":9.2043},
    {"name":"Firenze S. M. Novella","lat":43.7760,"lon":11.2480},

    # Mittel-/Nordeuropa
    {"name":"Praha hl.n.","lat":50.0833,"lon":14.4358},
    {"name":"Budapest Keleti","lat":47.5001,"lon":19.0822},
    {"name":"København H","lat":55.6738,"lon":12.5647},
    {"name":"Stockholm Central","lat":59.3300,"lon":18.0570},
    {"name":"Kraków Główny","lat":50.0650,"lon":19.9470},
    {"name":"Edinburgh Waverley","lat":55.9520,"lon":-3.1890},
    {"name":"London St Pancras","lat":51.5308,"lon":-0.1254},
]

# -------------------------------------------------------------
# Typische Startorte, die ohne Geocoding erkannt werden
# -------------------------------------------------------------
ORIGIN_POINTS = {
    "berlin":            (52.5200, 13.4050, "Berlin"),
    "berlin, de":        (52.5200, 13.4050, "Berlin"),
    "hamburg":           (53.5511, 9.9937,  "Hamburg"),
    "münchen":           (48.1374, 11.5755, "München"),
    "munich":            (48.1374, 11.5755, "Munich"),
    "frankfurt":         (50.1109, 8.6821,  "Frankfurt am Main"),
    "köln":              (50.9375, 6.9603,  "Köln"),
    "cologne":           (50.9375, 6.9603,  "Cologne"),
    "düsseldorf":        (51.2277, 6.7735,  "Düsseldorf"),
    "stuttgart":         (48.7758, 9.1829,  "Stuttgart"),
    "wien":              (48.2082, 16.3738, "Wien"),
    "vienna":            (48.2082, 16.3738, "Vienna"),
    "zürich":            (47.3769, 8.5417,  "Zürich"),
    "zurich":            (47.3769, 8.5417,  "Zurich"),
    "paris":             (48.8566, 2.3522,  "Paris"),
    "amsterdam":         (52.3676, 4.9041,  "Amsterdam"),
    "london":            (51.5074, -0.1278, "London"),
    "madrid":            (40.4168, -3.7038, "Madrid"),
    "barcelona":         (41.3851, 2.1734,  "Barcelona"),
    "rom":               (41.9028, 12.4964, "Rom"),
    "rome":              (41.9028, 12.4964, "Rome"),
    "lisbon":            (38.7223, -9.1393, "Lisbon"),
    "lissabon":          (38.7223, -9.1393, "Lissabon"),
}
