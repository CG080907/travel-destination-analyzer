# services/fx_service.py
from __future__ import annotations
import csv
from typing import Dict
from config import FX_CSV_PATH


class FXService:
    def __init__(self, csv_path: str | None = None) -> None:
        self.csv_path = csv_path or FX_CSV_PATH
        # Standard-Fallback-Raten, falls CSV fehlt / kaputt ist
        self.rates: Dict[str, float] = {
            "EUR": 1.0,
            "USD": 1.08,
            "GBP": 0.85,
            "CHF": 0.97,
        }
        self.load()

    @property
    def currencies(self):
        return sorted(self.rates.keys())

    def load(self) -> None:
        """
        Versucht zuerst, eine CSV mit Headern (ISO/Kurs) zu lesen.
        Wenn das nicht klappt, wird ein Fallback-Parser für dein Bankformat
        ohne Header verwendet:

            Land;Ländercode;Kurs;Währungscode;Von;Bis;...

        Beispiel:
            Australien;AU;1,7864;AUD;01.11.2025;30.11.2025;;
        """
        try:
            with open(self.csv_path, newline="", encoding="utf-8-sig") as f:
                # --- Versuch 1: CSV mit Headern (DictReader) ---
                try:
                    sniffer = csv.Sniffer()
                    sample = f.read(2048)
                    f.seek(0)
                    dialect = sniffer.sniff(sample)
                except Exception:
                    dialect = csv.excel

                reader = csv.DictReader(f, dialect=dialect)

                codes_field = None
                rate_field = None
                headers = [h.strip() for h in (reader.fieldnames or [])]

                for h in headers:
                    hl = h.lower()
                    if codes_field is None and hl in ("iso", "code", "währungscode", "currency", "iso-code"):
                        codes_field = h
                    if rate_field is None and hl in ("kurs", "rate", "kurs_eur", "exchange-rate", "wechselkurs"):
                        rate_field = h

                new_rates: Dict[str, float] = {"EUR": 1.0}

                if codes_field and rate_field:
                    # Normale CSV mit Kopfzeile
                    for row in reader:
                        code = (row.get(codes_field) or "").strip().upper()
                        if not code:
                            continue
                        val = (row.get(rate_field) or "").strip()
                        if not val:
                            continue
                        val = val.replace(",", ".")
                        try:
                            rate = float(val)
                        except ValueError:
                            continue
                        if rate <= 0:
                            continue
                        new_rates[code] = rate

                    if len(new_rates) > 1:
                        self.rates.update(new_rates)
                        print(f"✅ FX-Raten aus CSV geladen ({len(new_rates)} Einträge, Header-Modus).")
                        return
                    else:
                        print("⚠️  FX-CSV (Header-Modus) hatte keine verwertbaren Kurse, versuche Fallback-Format…")

                # --- Versuch 2: Fallback für dein Bankformat ohne Header ---
                f.seek(0)
                reader2 = csv.reader(f, delimiter=";")
                new_rates = {"EUR": 1.0}

                for row in reader2:
                    # Erwartetes Format:
                    # 0: Land
                    # 1: Ländercode
                    # 2: Kurs (z.B. 1,7864)
                    # 3: Währungscode (z.B. AUD)
                    if not row or len(row) < 4:
                        continue

                    raw_val = (row[2] or "").strip()
                    code = (row[3] or "").strip().upper()

                    if not raw_val or not code:
                        continue

                    # Dezimalkomma -> Dezimalpunkt
                    val = raw_val.replace(",", ".")
                    try:
                        rate = float(val)
                    except ValueError:
                        continue
                    if rate <= 0:
                        continue

                    new_rates[code] = rate

                if len(new_rates) > 1:
                    self.rates.update(new_rates)
                    print(f"✅ FX-Raten aus CSV geladen ({len(new_rates)} Einträge, Fallback-Format).")
                else:
                    print("⚠️  FX-CSV hatte keine verwertbaren Kurse (Fallback), nutze Standard-Raten.")

        except FileNotFoundError:
            print(f"ℹ️  FX-CSV nicht gefunden ({self.csv_path}), nutze Standard-Raten.")
        except Exception as e:
            print(f"⚠️  Fehler beim Laden von FX-CSV: {e}")

    def convert(self, amount: float, frm: str, to: str) -> float | None:
        frm = (frm or "EUR").upper()
        to  = (to  or "EUR").upper()
        if frm not in self.rates or to not in self.rates:
            return None
        try:
            eur = amount / self.rates[frm]
        except ZeroDivisionError:
            return None
        return eur * self.rates[to]
