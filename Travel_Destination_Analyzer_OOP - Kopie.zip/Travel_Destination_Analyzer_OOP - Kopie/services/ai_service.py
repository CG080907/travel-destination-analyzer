# services/ai_service.py
from __future__ import annotations
from typing import Optional
import json
from urllib import request, error
from config import GOOGLE_AI_STUDIO_API_KEY, GOOGLE_AI_STUDIO_MODEL, SSL_CTX

class AIService:
    def _http_post_json(self, url: str, body: dict, headers: dict | None = None) -> dict:
        data = json.dumps(body).encode("utf-8")
        hdrs = {"Content-Type":"application/json"}
        if headers:
            hdrs.update(headers)
        req = request.Request(url, data=data, headers=hdrs)
        with request.urlopen(req, context=SSL_CTX, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8") or "{}")

    def ask(self, q: str) -> tuple[Optional[str], Optional[str]]:
        if not GOOGLE_AI_STUDIO_API_KEY:
            return None, "Kein GOOGLE_AI_STUDIO_API_KEY gesetzt."
        models = [
            GOOGLE_AI_STUDIO_MODEL or "gemini-2.5-flash",
            "gemini-2.5-flash-lite",
            "gemini-2.5-pro",
        ]
        tried = set()
        text = None
        last_err = None
        for model in models:
            if not model or model in tried:
                continue
            tried.add(model)
            try:
                endpoint = (
                    "https://generativelanguage.googleapis.com/v1beta/models/"
                    + model
                    + ":generateContent"
                )
                body = {"contents":[{"parts":[{"text": q}]}]}
                jr = self._http_post_json(endpoint, body, {"x-goog-api-key": GOOGLE_AI_STUDIO_API_KEY})
                try:
                    text = jr["candidates"][0]["content"]["parts"][0]["text"]
                except Exception:
                    cand = (jr.get("candidates") or [{}])[0]
                    content = cand.get("content") or {}
                    parts = content.get("parts") or []
                    if parts and isinstance(parts[0], dict):
                        text = parts[0].get("text")
                    else:
                        text = None
                if text:
                    break
            except error.HTTPError as e:
                try:
                    detail = e.read().decode('utf-8', 'ignore')
                except Exception:
                    detail = ""
                last_err = f"HTTP {e.code}: {detail}"
                if e.code in (404, 400):
                    continue
                else:
                    break
            except Exception as e:
                last_err = str(e)
                break
        return text, last_err
