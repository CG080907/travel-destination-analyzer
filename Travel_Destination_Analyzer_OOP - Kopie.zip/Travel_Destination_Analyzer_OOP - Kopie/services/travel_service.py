# services/travel_service.py
from __future__ import annotations
from typing import Dict, Any, List
import math
import datetime as dt
from urllib.parse import quote_plus
from models import TravelRequest
from .destinations_data import DESTINATIONS, TRIP_PROFILES, city_key, AIRPORTS, TRAIN_HUBS
from .climate_service import ClimateService
from .booking_service import BookingService
from .geocode_service import GeocodeService


def haversine_km(lat1, lon1, lat2, lon2) -> float:
    R = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlmb = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlmb / 2) ** 2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def nearest_point(lat, lon, items, key_lat="lat", key_lon="lon"):
    best, best_d = None, 1e18
    for it in items:
        d = haversine_km(lat, lon, it[key_lat], it[key_lon])
        if d < best_d:
            best_d, best = d, it
    return best, best_d


def nights_between(checkin: str, checkout: str, default_nights: int = 5) -> int:
    try:
        if not checkin or not checkout:
            return default_nights
        d1 = dt.date.fromisoformat(checkin)
        d2 = dt.date.fromisoformat(checkout)
        return max(1, (d2 - d1).days)
    except Exception:
        return default_nights


def score_base(seasonal: float, cond_cat: str, ppd: float,
               tmin: float, tmax: float, budget: float) -> float:
    """
    Strengeres Scoring:
    - Temperatur: stärker bestraft, wenn außerhalb des gewünschten Bereichs
    - Preis: teure Ziele werden deutlich abgestraft
    """
    s = 100.0

    # Wunschtemperatur
    target_mid = (tmin + tmax) / 2.0
    diff_mid = abs(seasonal - target_mid)
    s -= diff_mid * 4.0

    if seasonal < tmin:
        diff = tmin - seasonal
        s -= diff * 3.0
    elif seasonal > tmax:
        diff = seasonal - tmax
        s -= diff * 3.0

    # Budget
    if budget <= 0:
        budget = 1.0
    if ppd <= budget:
        under = (budget - ppd) / budget
        s += min(under * 10.0, 5.0)
    else:
        over_rel = (ppd - budget) / budget
        s -= over_rel * 120.0
        if ppd > budget * 1.5:
            s -= 10.0
        if ppd > budget * 2.0:
            s -= 20.0

    # Wetter-Kategorie
    if cond_cat == "Clear":
        s += 5.0
    elif cond_cat in ("Rain", "Snow"):
        s -= 10.0
    elif cond_cat == "Storm":
        s -= 15.0

    return s


def profile_bonus(tags: list[str], trip_type: str) -> float:
    wanted = TRIP_PROFILES.get(trip_type, [])
    if not wanted:
        return 0.0
    fit = len(set(t.lower() for t in tags).intersection(set(wanted))) / max(1, len(wanted))
    return 10.0 * fit


def travel_estimate(lat_o, lon_o, lat_d, lon_d, mode: str) -> dict:
    if None in (lat_o, lon_o, lat_d, lon_d):
        return {"distance_km": None, "time_h": None, "cost_eur": None}
    base = haversine_km(lat_o, lon_o, lat_d, lon_d)
    factor = 1.0
    if mode == "train":
        factor = 1.10
    elif mode == "car":
        factor = 1.20
    dist = base * factor

    if mode == "flight":
        speed = 800.0
        base_h = 1.5
        eur_per_km = 0.07
        base_fee = 60.0
        t = dist / speed + base_h
        c = dist * eur_per_km + base_fee
    elif mode == "train":
        speed = 130.0
        eur_per_km = 0.18
        t = dist / speed
        c = dist * eur_per_km
    else:
        speed = 90.0
        eur_per_km = 0.22
        t = dist / speed
        c = dist * eur_per_km

    return {
        "distance_km": round(dist, 1),
        "time_h": round(t, 1),
        "cost_eur": round(c, 2),
    }


def budget_estimate(adults: int, nights: int, ppd: float,
                    travel_cost_total: float | None, activities_per_day: float) -> dict:
    stay = round(ppd * max(1, adults) * max(1, nights), 2)
    travel = round(travel_cost_total or 0.0, 2)
    acts = round(activities_per_day * max(1, nights) * max(1, adults), 2)
    total = round(stay + travel + acts, 2)
    return {"stay": stay, "travel": travel, "activities": acts, "total": total}


def booking_search_url(city: str, checkin: str, checkout: str, adults: int) -> str:
    q = quote_plus(city_key(city))
    ci = checkin or "2025-06-01"
    co = checkout or "2025-06-06"
    return (
        "https://www.booking.com/searchresults.de.html"
        f"?ss={q}&checkin={ci}&checkout={co}&group_adults={max(1, adults)}&no_rooms=1"
    )


def gmaps_drive_url(origin_name: str, lat_d: float, lon_d: float) -> str:
    o = quote_plus(origin_name or "")
    return f"https://www.google.com/maps/dir/{o}/{lat_d:.6f},{lon_d:.6f}"


def skyscanner_url(dep_code: str, dest_city: str) -> str:
    return (
        "https://www.skyscanner.de/transport/fluge/"
        f"{dep_code.lower()}/anywhere/?adultsv2=1#results"
    )


def trainline_url(origin_city: str, dest_city: str) -> str:
    return (
        "https://www.trainline.eu/search/"
        f"{quote_plus(origin_city)}/{quote_plus(dest_city)}"
    )


def google_images_url(city: str) -> str:
    return f"https://www.google.com/search?tbm=isch&q={quote_plus(city_key(city) + ' sights')}"


def guides_offline(destination: str) -> list[dict]:
    base = city_key(destination)
    return [
        {
            "title": f"Walking Tour in {base}",
            "price_eur": None,
            "url": f"https://www.google.com/search?q={quote_plus(base + ' city tour')}",
        },
        {
            "title": f"Food Highlights in {base}",
            "price_eur": None,
            "url": f"https://www.google.com/search?q={quote_plus(base + ' food tour')}",
        },
        {
            "title": f"Top Sights in {base}",
            "price_eur": None,
            "url": f"https://www.google.com/search?q={quote_plus(base + ' top sights')}",
        },
    ]


def classify_hotel(ppd: float) -> str:
    """
    Grobe Einordnung, was man für den Preis pro Nacht / Person erwarten kann.
    """
    if ppd < 70:
        return "einfache Pension, Hostel oder günstige Ferienwohnung"
    elif ppd < 140:
        return "gutes Mittelklasse-Hotel oder solide Ferienwohnung"
    else:
        return "gehobenes Hotel oder hochwertiges Apartment"


class TravelService:
    def __init__(
        self,
        climate: ClimateService,
        booking: BookingService,
        geocode: GeocodeService,
    ) -> None:
        self.climate = climate
        self.booking = booking
        self.geocode = geocode

    def analyze(self, req: TravelRequest) -> list[dict]:
        o_lat, o_lon, o_name = self.geocode.resolve_origin(req.origin)
        rows: list[dict] = []

        for d in DESTINATIONS:
            # Klima
            seas, cond_cat, cond_de, cond_en = self.climate.seasonal_temp_and_condition(
                d["name"], req.checkin
            )

            # Unterkunftskosten (Booking, falls verfügbar)
            avg_price, _hotels = self.booking.booking_avg_price_and_hotels(
                d["name"], req.checkin, req.checkout, req.adults
            )
            if avg_price:
                # pro Person / Nacht
                ppd = round(avg_price / max(1, req.adults), 2)
            else:
                ppd = float(d["avg_cost_per_day"])

            # Score
            base = score_base(seas, cond_cat, ppd, req.tmin, req.tmax, req.budget)
            bonus = profile_bonus(d.get("tags", []), req.triptype)
            sc_raw = base + bonus
            sc = max(0.0, min(100.0, round(sc_raw, 1)))

            # Reise
            if o_lat is not None:
                trv = travel_estimate(o_lat, o_lon, d["lat"], d["lon"], req.mode)
            else:
                trv = {"cost_eur": 0.0, "distance_km": None, "time_h": None}

            # Hin- und Rückreise trennen (approx.)
            if trv.get("cost_eur") is not None:
                trv["oneway_cost_eur"] = round(trv["cost_eur"] / 2.0, 2)
            else:
                trv["oneway_cost_eur"] = None

            # Aufenthalt + Aktivitäten
            nights = nights_between(req.checkin, req.checkout, default_nights=5)
            bud = budget_estimate(
                req.adults,
                nights,
                ppd,
                trv.get("cost_eur"),
                req.actppd,
            )

            # Links für Buttons
            suggested = None
            travel_link = None
            if o_lat is not None:
                if req.mode == "car":
                    travel_link = gmaps_drive_url(o_name or req.origin, d["lat"], d["lon"])
                elif req.mode == "flight":
                    dep, _ = nearest_point(o_lat, o_lon, AIRPORTS)
                    if dep:
                        suggested = {"type": "airport", "code": dep["code"], "name": dep["name"]}
                    travel_link = skyscanner_url(
                        dep["code"] if dep else "any", city_key(d["name"])
                    )
                elif req.mode == "train":
                    dep, _ = nearest_point(o_lat, o_lon, TRAIN_HUBS)
                    if dep:
                        suggested = {"type": "train", "name": dep["name"]}
                    travel_link = trainline_url(o_name or req.origin, d["name"])

            links = {
                "stay": booking_search_url(d["name"], req.checkin, req.checkout, req.adults),
                "travel": travel_link,
                "activities": "https://www.google.com/search?q="
                + quote_plus(city_key(d["name"]) + " activities"),
                "photos": google_images_url(d["name"]),
            }

            # Meta-Infos für das Frontend („was bekomme ich für mein Geld?“)
            meta = {
                "nights": nights,
                "adults": req.adults,
                "actppd": req.actppd,  # pro Person pro Tag
            }

            rows.append(
                {
                    "destination": d["name"],
                    "score": sc,
                    "season_temp": float(seas),
                    "condition": cond_de,
                    "condition_en": cond_en,
                    "cost_ppd": ppd,
                    "lat": d["lat"],
                    "lon": d["lon"],
                    "budget_total": bud["total"],
                    "country": d.get("country", ""),
                    "travel": trv,
                    "costs": bud,
                    "links": links,
                    "suggested": suggested,
                    "meta": meta,
                    "hotel_desc": classify_hotel(ppd),
                }
            )

        rows.sort(key=lambda r: r["score"], reverse=True)
        return rows
