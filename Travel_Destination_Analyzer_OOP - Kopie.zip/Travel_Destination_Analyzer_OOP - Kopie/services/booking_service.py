# services/booking_service.py
from __future__ import annotations
from typing import Tuple, List, Dict, Any
from urllib import request
from urllib.parse import urlencode
import json
from config import SSL_CTX, BOOKING_RAPIDAPI_KEY, BOOKING_RAPIDAPI_HOST
import datetime as dt

class BookingService:
    def _http_get_json(self, url: str, headers: dict | None = None) -> dict:
        req = request.Request(url, headers=headers or {"User-Agent":"travel-webapp/1.0"})
        with request.urlopen(req, context=SSL_CTX, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8") or "{}")

    def nights_between(self, checkin: str, checkout: str, default_nights: int = 5) -> int:
        try:
            if not checkin or not checkout:
                return default_nights
            d1 = dt.date.fromisoformat(checkin); d2 = dt.date.fromisoformat(checkout)
            return max(1, (d2 - d1).days)
        except Exception:
            return default_nights

    def booking_avg_price_and_hotels(
        self, city: str, checkin: str, checkout: str, adults: int
    ) -> tuple[float|None, list]:
        if not (BOOKING_RAPIDAPI_KEY and BOOKING_RAPIDAPI_HOST):
            return (None, [])
        try:
            u1 = f"https://{BOOKING_RAPIDAPI_HOST}/v1/hotels/locations?{urlencode({'name':city.split(',')[0],'locale':'de'})}"
            j1 = self._http_get_json(u1, {
                "x-rapidapi-key":BOOKING_RAPIDAPI_KEY,
                "x-rapidapi-host":BOOKING_RAPIDAPI_HOST
            })
            if not j1:
                return (None, [])
            dest_id = None
            for item in j1:
                if item.get("dest_type") in ("city","region","district"):
                    dest_id = item.get("dest_id")
                    break
            if not dest_id:
                dest_id = j1[0].get("dest_id")
            nights = self.nights_between(checkin, checkout)
            params = {
                "adults_number": max(1, adults),
                "checkin_date": checkin or "2025-06-01",
                "checkout_date": checkout or "2025-06-06",
                "dest_id": dest_id, "dest_type": "city",
                "order_by": "price", "filter_by_currency": "EUR",
                "locale": "de", "units": "metric",
                "page_number": "0", "room_number": "1",
            }
            u2 = f"https://{BOOKING_RAPIDAPI_HOST}/v1/hotels/search?{urlencode(params)}"
            j2 = self._http_get_json(u2, {
                "x-rapidapi-key":BOOKING_RAPIDAPI_KEY,
                "x-rapidapi-host":BOOKING_RAPIDAPI_HOST
            })
            result = j2.get("result") or []
            hotels, prices = [], []
            for r in result[:15]:
                name = (r.get("hotel_name")
                        or r.get("hotel_name_trans")
                        or r.get("property_name")
                        or r.get("name"))
                price_total = None
                pb = r.get("price_breakdown")
                if isinstance(pb, dict) and pb.get("gross_price"):
                    price_total = float(pb["gross_price"])
                elif r.get("min_total_price"):
                    price_total = float(r["min_total_price"])
                review = r.get("review_score")
                acc_type = r.get("accommodation_type_name") or r.get("accommodation_type") or ""
                if name and price_total:
                    per_night = max(1.0, round(price_total / max(1,nights), 2))
                    hotels.append({"name": name, "price_per_night": per_night,
                                   "review_score": review, "type": acc_type})
                    prices.append(per_night)
            avg = round(sum(prices)/len(prices), 2) if prices else None
            return (avg, hotels)
        except Exception:
            return (None, [])
