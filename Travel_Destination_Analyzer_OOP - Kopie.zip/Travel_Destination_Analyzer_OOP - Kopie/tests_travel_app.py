# tests/test_core_logic.py
import unittest
import copy
import datetime as dt

# Diese Imports passen zur OOP-Struktur:
from services.climate_service import ClimateService
from services.fx_service import FXService
from services.travel_service import TravelService, haversine_km, nights_between
from services.hazards_service import HazardsService
from models import TravelRequest


class TestClimateService(unittest.TestCase):
    def setUp(self):
        # wir nehmen an, dass ClimateService intern ein CLIMATE-Dict hält
        self.service = ClimateService()

    def test_seasonal_temp_fallback_summer(self):
        """
        Wenn die Stadt nicht in der CSV ist, sollte der Sommer-Fallback greifen
        (z.B. klar, um die 24 °C).
        """
        temp, cond_cat, text_de, text_en = self.service.seasonal_temp_and_condition(
            "Fantasiastadt, XX", "2025-07-15"
        )
        self.assertIsInstance(temp, (int, float))
        self.assertGreaterEqual(temp, 15.0)
        self.assertLessEqual(temp, 35.0)
        self.assertIsInstance(cond_cat, str)
        self.assertTrue(text_de)
        self.assertTrue(text_en)

    def test_seasonal_temp_with_known_city(self):
        """
        Für eine echte Destination sollte ein sinnvoller Wert aus der CSV kommen.
        (wenn Klimadaten vorhanden sind)
        """
        temp, cond_cat, text_de, text_en = self.service.seasonal_temp_and_condition(
            "Mallorca, ES", "2025-06-15"
        )
        self.assertIsInstance(temp, (int, float))
        self.assertNotEqual(cond_cat, "")
        self.assertTrue(text_de)
        self.assertTrue(text_en)


class TestFXService(unittest.TestCase):
    def setUp(self):
        self.fx = FXService()
        # wir sichern uns die alten Raten, falls die Klasse so etwas hat
        self._orig_rates = copy.deepcopy(getattr(self.fx, "rates", {}))

    def tearDown(self):
        if hasattr(self.fx, "rates"):
            self.fx.rates = self._orig_rates

    def test_convert_symmetric(self):
        """
        Einfache Konsistenz:
        10 EUR -> X USD -> zurück -> wieder ~10 EUR.
        """
        amount = 10.0
        eur_to_usd = self.fx.convert(amount, "EUR", "USD")
        back_to_eur = self.fx.convert(eur_to_usd, "USD", "EUR")
        self.assertIsInstance(eur_to_usd, float)
        self.assertIsInstance(back_to_eur, float)
        # kleine Rundungsabweichung erlauben
        self.assertAlmostEqual(amount, back_to_eur, delta=0.5)

    def test_list_currencies_contains_eur(self):
        currs = self.fx.list_currencies()
        self.assertIn("EUR", currs)


class TestTravelServiceGeo(unittest.TestCase):
    def setUp(self):
        self.travel = TravelService(
            climate_service=ClimateService(),
            fx_service=FXService(),
            hazards_service=HazardsService(),
        )

    def test_haversine_symmetry(self):
        """
        haversine_km(a,b) == haversine_km(b,a) und Distanz plausibel.
        """
        berlin = (52.5200, 13.4050)
        hamburg = (53.5511, 9.9937)
        d1 = haversine_km(berlin[0], berlin[1], hamburg[0], hamburg[1])
        d2 = haversine_km(hamburg[0], hamburg[1], berlin[0], berlin[1])
        self.assertAlmostEqual(d1, d2, delta=0.001)
        self.assertGreater(d1, 200.0)
        self.assertLess(d1, 400.0)

    def test_nights_between(self):
        self.assertEqual(nights_between("2025-06-01", "2025-06-06"), 5)
        # Ungültige Eingaben -> Default 5
        self.assertEqual(nights_between("2025-06-01", ""), 5)
        self.assertEqual(nights_between("", ""), 5)


class TestTravelServiceAnalyze(unittest.TestCase):
    """
    Integrationstest für die Analyse-Logik, aber ohne externe HTTP-APIs:
    Wir gehen davon aus, dass TravelService.analyze so gebaut ist,
    dass er Booking/Skyscanner optional/fail-safe behandelt.
    """

    def setUp(self):
        self.travel = TravelService(
            climate_service=ClimateService(),
            fx_service=FXService(),
            hazards_service=HazardsService(),
        )

    def test_analyze_simple_request(self):
        """
        Ein einfacher Request für einen Citytrip im Sommer.
        Erwartung: mindestens 1 Ergebnis, Score in [0,100], Budget > 0.
        """
        req = TravelRequest(
            checkin="2025-06-15",
            checkout="2025-06-20",
            adults=2,
            budget_per_day=150.0,
            tmin=20.0,
            tmax=30.0,
            triptype="city",
            origin="Berlin",
            mode="car",
            activities_per_day=20.0,
        )

        rows = self.travel.analyze(req)
        self.assertIsInstance(rows, list)
        self.assertGreater(len(rows), 0)

        first = rows[0]
        # wir nehmen an, dass TravelResultRow Properties hat wie destination, score, budget_total etc.
        self.assertTrue(hasattr(first, "destination"))
        self.assertTrue(hasattr(first, "score"))
        self.assertTrue(0.0 <= first.score <= 100.0)
        self.assertTrue(hasattr(first, "budget_total"))
        self.assertGreater(first.budget_total, 0.0)


class TestHazardsService(unittest.TestCase):
    def setUp(self):
        self.haz = HazardsService()

    def test_get_hazards_for_known_country(self):
        """
        Für bekannte Ländercodes (z.B. ES, IT, FR, DE) sollte es mindestens
        eine Warnung geben.
        """
        items = self.haz.get_hazards("ES")
        self.assertIsInstance(items, list)
        self.assertGreaterEqual(len(items), 1)

    def test_aa_link_contains_country_name(self):
        """
        Der Link des Auswärtigen Amts sollte den Ländernamen enthalten
        (in irgendeiner Form, URL-encoded ist ok).
        """
        url = self.haz.aa_link("ES")
        # darf None sein, wenn Service so designed ist – dann schlagen wir hier nicht hart zu
        if url is not None:
            self.assertIn("spanien".lower(), url.lower() or "")
        # falls None, akzeptieren wir das – dann ist das Feature einfach nicht aktiv.


if __name__ == "__main__":
    unittest.main()
